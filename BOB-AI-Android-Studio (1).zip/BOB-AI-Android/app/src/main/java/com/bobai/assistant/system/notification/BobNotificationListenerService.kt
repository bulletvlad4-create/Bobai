package com.bobai.assistant.system.notification

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

data class CapturedNotification(
    val packageName: String,
    val title: String,
    val text: String,
    val postTime: Long
)

class BobNotificationListenerService : NotificationListenerService() {

    companion object {
        @Volatile
        var isConnected: Boolean = false
            private set

        private val recentNotifications = ArrayDeque<CapturedNotification>(25)

        fun getRecentNotifications(): List<CapturedNotification> =
            synchronized(recentNotifications) { recentNotifications.toList() }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        isConnected = true
    }

    override fun onListenerDisconnected() {
        isConnected = false
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val extras = sbn?.notification?.extras ?: return
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val text = extras.getCharSequence("android.text")?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        synchronized(recentNotifications) {
            if (recentNotifications.size >= 25) recentNotifications.removeLast()
            recentNotifications.addFirst(
                CapturedNotification(
                    packageName = sbn.packageName.orEmpty(),
                    title = title,
                    text = text,
                    postTime = sbn.postTime
                )
            )
        }
    }
}
