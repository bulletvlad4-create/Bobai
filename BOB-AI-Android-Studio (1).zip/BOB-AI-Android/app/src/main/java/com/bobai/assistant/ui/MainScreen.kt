package com.bobai.assistant.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bobai.assistant.domain.model.AiProviderConfig
import com.bobai.assistant.domain.model.AvatarState
import com.bobai.assistant.domain.model.ModelRole

@Composable
fun MainScreen(
    viewModel: MainViewModel,
    onRequestPermissionAction: (String) -> Unit,
    onStartForegroundService: () -> Unit
) {
    val avatarState by viewModel.avatarState.collectAsState()
    val pipeline by viewModel.pipeline.collectAsState()
    val isListening by viewModel.isListening.collectAsState()
    val partialTranscript by viewModel.partialTranscript.collectAsState()
    val wakeWordActive by viewModel.wakeWordModeActive.collectAsState()
    val speechError by viewModel.speechError.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()
    val availableVoices by viewModel.availableVoices.collectAsState()
    val selectedVoiceName by viewModel.selectedVoiceName.collectAsState()
    val speechRate by viewModel.speechRate.collectAsState()
    val continuousDialogue by viewModel.continuousDialogue.collectAsState()
    val hasMediaProjection by viewModel.hasMediaProjectionConsent.collectAsState()
    val previewEnabled by viewModel.screenshotPreviewEnabled.collectAsState()
    val lastPreviewBitmap by viewModel.lastPreviewBitmap.collectAsState()
    val memories by viewModel.memories.collectAsState()
    val logs by viewModel.actionLogs.collectAsState()
    val chat by viewModel.chatMessages.collectAsState()
    val permissions by viewModel.permissions.collectAsState()
    val providers by viewModel.providers.collectAsState()
    val assistantEnabled by viewModel.assistantEnabled.collectAsState()
    val visionCallsToday by viewModel.visionCallsToday.collectAsState()
    val visionRoleProviderId by viewModel.visionRoleProviderId.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }
    var commandInput by remember { mutableStateOf("") }
    var showAddMemoryDialog by remember { mutableStateOf(false) }
    var editingProvider by remember { mutableStateOf<AiProviderConfig?>(null) }

    val statusText = when {
        pipeline.isAnalyzingScreen -> "Анализ экрана (${pipeline.visualStepCount}/${pipeline.visualMaxSteps})"
        isListening -> "Слушаю микрофон..."
        isSpeaking -> "Озвучиваю ответ"
        avatarState == AvatarState.PROCESSING -> "Планирование"
        avatarState == AvatarState.EXECUTING -> "Выполнение"
        avatarState == AvatarState.ERROR -> "Ошибка"
        else -> "Готов"
    }

    pipeline.awaitingConfirmation?.let { step ->
        AlertDialog(
            onDismissRequest = { viewModel.rejectPendingStep() },
            title = { Text("Подтверждение безопасности") },
            text = {
                Text(step.confirmationPrompt ?: "Выполнить потенциально чувствительное действие «${step.humanLabel}»?")
            },
            confirmButton = {
                Button(onClick = { viewModel.confirmPendingStep() }) {
                    Text("Подтвердить")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { viewModel.rejectPendingStep() }) {
                    Text("Отмена")
                }
            }
        )
    }

    if (showAddMemoryDialog) {
        MemoryEditorDialog(
            onDismiss = { showAddMemoryDialog = false },
            onSave = { cat, key, content ->
                viewModel.addOrUpdateMemory(cat, key, content)
                showAddMemoryDialog = false
            }
        )
    }

    editingProvider?.let { cfg ->
        ProviderEditorDialog(
            config = cfg,
            maskedKey = viewModel.getApiKeyMasked(cfg.id),
            onDismiss = { editingProvider = null },
            onSave = { updatedCfg, newKey ->
                viewModel.updateProvider(updatedCfg, newKey)
                editingProvider = null
            }
        )
    }

    Scaffold(
        containerColor = Color(0xFF090C12),
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF111622)) {
                val tabs = listOf(
                    "Боб" to Icons.Default.Home,
                    "Чат" to Icons.Default.Chat,
                    "Память" to Icons.Default.Memory,
                    "История" to Icons.Default.History,
                    "Система" to Icons.Default.Settings
                )
                tabs.forEachIndexed { idx, (label, icon) ->
                    NavigationBarItem(
                        selected = selectedTab == idx,
                        onClick = { selectedTab = idx },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, fontSize = 11.sp, maxLines = 1) }
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("BOB AI", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text(
                        text = if (wakeWordActive) "Режим «Привет, Боб» активен (экран/сессия)" else "Голосовой и визуальный агент",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
                Text(
                    text = statusText,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (pipeline.isAnalyzingScreen) Color(0xFFC084FC) else Color(0xFF38BDF8)
                )
            }

            if (pipeline.isAnalyzingScreen) {
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF2E1065).copy(alpha = 0.65f))
                        .border(1.dp, Color(0xFFA855F7), RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Visibility,
                            contentDescription = "Visual Agent",
                            tint = Color(0xFFD8B4FE),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Боб анализирует экран · Шаг ${pipeline.visualStepCount}/${pipeline.visualMaxSteps}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFFF3E8FF)
                            )
                            Text(
                                text = pipeline.visualPhase.ifBlank { "Захват и поиск элементов..." },
                                fontSize = 11.sp,
                                color = Color(0xFFD8B4FE)
                            )
                        }
                    }
                    OutlinedButton(onClick = { viewModel.cancelExecution() }) {
                        Text("Стоп", fontSize = 11.sp)
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            when (selectedTab) {
                0 -> HomeAgentTab(
                    modifier = Modifier.weight(1f),
                    avatarState = if (isListening) AvatarState.LISTENING else avatarState,
                    pipeline = pipeline,
                    partialTranscript = partialTranscript,
                    speechError = speechError,
                    hasMediaProjection = hasMediaProjection,
                    previewEnabled = previewEnabled,
                    lastPreviewBitmap = lastPreviewBitmap,
                    onAvatarTap = { viewModel.toggleVoiceListening() },
                    onStopSpeaking = { viewModel.stopSpeaking() },
                    onCancelTask = { viewModel.cancelExecution() },
                    onRequestScreenCapture = { onRequestPermissionAction("media_projection") },
                    onCapturePreview = { viewModel.captureSinglePreviewFrame() }
                )

                1 -> LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (chat.isEmpty()) {
                        item {
                            Text(
                                "История диалога пуста. Задайте голосовую или текстовую команду ниже.",
                                color = Color(0xFF94A3B8),
                                fontSize = 13.sp
                            )
                        }
                    }
                    items(chat, key = { it.id }) { msg ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF111622))
                                .border(1.dp, Color(0xFF1F293B), RoundedCornerShape(10.dp))
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (msg.role == "user") "Вы" else "Боб",
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF38BDF8),
                                    fontSize = 12.sp
                                )
                                msg.modelUsed?.let {
                                    Text(it, fontSize = 11.sp, color = Color(0xFF64748B))
                                }
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(msg.text, fontSize = 14.sp, color = Color(0xFFF1F5F9))
                        }
                    }
                }

                2 -> MemoryTab(
                    modifier = Modifier.weight(1f),
                    memories = memories,
                    onOpenAdd = { showAddMemoryDialog = true },
                    onDelete = { viewModel.deleteMemory(it) }
                )

                3 -> Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Журнал действий (${logs.size})",
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                        if (logs.isNotEmpty()) {
                            OutlinedButton(onClick = { viewModel.clearLogs() }) {
                                Text("Очистить", fontSize = 12.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(logs, key = { it.id }) { log ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF111622))
                                    .border(1.dp, Color(0xFF1F293B), RoundedCornerShape(10.dp))
                                    .padding(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        log.humanLabel,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp,
                                        color = Color(0xFFF1F5F9),
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = if (log.verified) "${log.status} · проверено" else log.status,
                                        fontSize = 11.sp,
                                        color = if (log.status == "COMPLETED") Color(0xFF10B981) else Color(0xFFF59E0B)
                                    )
                                }
                                Text(log.details, fontSize = 12.sp, color = Color(0xFF94A3B8))
                            }
                        }
                    }
                }

                4 -> SystemAndOnboardingTab(
                    modifier = Modifier.weight(1f),
                    permissions = permissions,
                    providers = providers,
                    visionRoleProviderId = visionRoleProviderId,
                    visionCallsToday = visionCallsToday,
                    assistantEnabled = assistantEnabled,
                    wakeWordActive = wakeWordActive,
                    continuousDialogue = continuousDialogue,
                    speechRate = speechRate,
                    availableVoices = availableVoices.map { it.name },
                    selectedVoiceName = selectedVoiceName,
                    previewEnabled = previewEnabled,
                    onRequestPermission = onRequestPermissionAction,
                    onStartForegroundService = onStartForegroundService,
                    onToggleAssistant = { viewModel.setAssistantEnabled(it) },
                    onToggleWakeWord = { viewModel.toggleWakeWordMode() },
                    onToggleContinuous = { viewModel.setContinuousDialogue(it) },
                    onSpeechRateChange = { viewModel.setSpeechRate(it) },
                    onSelectVoice = { viewModel.setVoiceName(it) },
                    onToggleScreenshotPreview = { viewModel.setScreenshotPreviewEnabled(it) },
                    onEditProvider = { editingProvider = it },
                    onSelectVisionProvider = { viewModel.bindModelRole(ModelRole.VISION_AGENT, it) },
                    getMaskedKey = { viewModel.getApiKeyMasked(it) }
                )
            }

            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = commandInput,
                    onValueChange = { commandInput = it },
                    placeholder = { Text("Команда или «Привет, Боб»...", fontSize = 13.sp) },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                IconButton(onClick = { viewModel.toggleVoiceListening() }) {
                    Icon(
                        Icons.Default.Mic,
                        contentDescription = "Голос",
                        tint = if (isListening) Color(0xFF22D3EE) else Color(0xFF38BDF8)
                    )
                }
                Button(
                    onClick = {
                        viewModel.submitCommand(commandInput)
                        commandInput = ""
                    },
                    enabled = commandInput.isNotBlank()
                ) {
                    Text("Пуск")
                }
            }
        }
    }
}

@Composable
private fun HomeAgentTab(
    modifier: Modifier,
    avatarState: AvatarState,
    pipeline: com.bobai.assistant.domain.model.PipelineStatus,
    partialTranscript: String,
    speechError: String?,
    hasMediaProjection: Boolean,
    previewEnabled: Boolean,
    lastPreviewBitmap: android.graphics.Bitmap?,
    onAvatarTap: () -> Unit,
    onStopSpeaking: () -> Unit,
    onCancelTask: () -> Unit,
    onRequestScreenCapture: () -> Unit,
    onCapturePreview: () -> Unit
) {
    LazyColumn(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            BobAvatarOrb(state = avatarState, onClick = onAvatarTap)
            if (partialTranscript.isNotBlank()) {
                Text(
                    text = "Распознаётся: «$partialTranscript»",
                    fontSize = 12.sp,
                    color = Color(0xFF22D3EE)
                )
            }
            if (!speechError.isNullOrBlank()) {
                Text(speechError, fontSize = 12.sp, color = Color(0xFFF59E0B))
            }
        }

        item {
            Surface(
                color = Color(0xFF111622),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF1F293B), RoundedCornerShape(12.dp))
            ) {
                Column(
                    Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text("Услышано: ${pipeline.heard.ifBlank { "—" }}", fontSize = 13.sp, color = Color(0xFFF1F5F9))
                    Text("Понято: ${pipeline.understood.ifBlank { "—" }}", fontSize = 13.sp, color = Color(0xFF94A3B8))
                    if (pipeline.currentlyExecuting.isNotBlank()) {
                        Text("Выполняется: ${pipeline.currentlyExecuting}", fontSize = 13.sp, color = Color(0xFF38BDF8))
                    }
                    pipeline.lastVisualDecision?.let { vd ->
                        Text(
                            text = "Экран (ИИ): ${vd.screenDescription} · ${vd.action} (${(vd.confidence * 100).toInt()}%)",
                            fontSize = 12.sp,
                            color = Color(0xFFD8B4FE)
                        )
                    }
                    if (!pipeline.errorBanner.isNullOrBlank()) {
                        Text("Ошибка: ${pipeline.errorBanner}", fontSize = 12.sp, color = Color(0xFFEF4444))
                    }
                    pipeline.completedSteps.forEach { done ->
                        Text("• $done", fontSize = 12.sp, color = Color(0xFF10B981))
                    }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onStopSpeaking) {
                    Icon(Icons.Default.Stop, contentDescription = "Стоп", modifier = Modifier.size(16.dp))
                    Text(" Перебить", fontSize = 12.sp)
                }
                OutlinedButton(onClick = onCancelTask) {
                    Text("Остановить всё", fontSize = 12.sp)
                }
                if (!hasMediaProjection) {
                    Button(onClick = onRequestScreenCapture) {
                        Text("Экран (Vision)", fontSize = 12.sp)
                    }
                }
            }
        }

        if (previewEnabled) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF111622))
                        .border(1.dp, Color(0xFF1F293B), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Последний снимок экрана", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                        OutlinedButton(onClick = if (hasMediaProjection) onCapturePreview else onRequestScreenCapture) {
                            Text(if (hasMediaProjection) "Снять экран" else "Разрешить", fontSize = 11.sp)
                        }
                    }
                    if (lastPreviewBitmap != null) {
                        Image(
                            bitmap = lastPreviewBitmap.asImageBitmap(),
                            contentDescription = "Последний скриншот Visual Agent",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                                .clip(RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.Fit
                        )
                    } else {
                        Text(
                            "Снимок появится здесь после анализа экрана Visual Agent.",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MemoryTab(
    modifier: Modifier,
    memories: List<com.bobai.assistant.data.local.MemoryEntity>,
    onOpenAdd: () -> Unit,
    onDelete: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filtered = remember(memories, searchQuery) {
        if (searchQuery.isBlank()) memories
        else memories.filter {
            it.key.contains(searchQuery, ignoreCase = true) ||
                it.content.contains(searchQuery, ignoreCase = true) ||
                it.category.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Поиск в памяти Room...", fontSize = 13.sp) },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
            Button(onClick = onOpenAdd) {
                Icon(Icons.Default.Add, contentDescription = "Добавить", modifier = Modifier.size(16.dp))
                Text(" Новая", fontSize = 12.sp)
            }
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(filtered, key = { it.id }) { mem ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF111622))
                        .border(1.dp, Color(0xFF1F293B), RoundedCornerShape(10.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("${mem.key} · ${mem.category}", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = Color.White)
                        Text(mem.content, fontSize = 12.sp, color = Color(0xFF94A3B8))
                    }
                    IconButton(onClick = { onDelete(mem.id) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Удалить", tint = Color(0xFFEF4444))
                    }
                }
            }
        }
    }
}

@Composable
private fun SystemAndOnboardingTab(
    modifier: Modifier,
    permissions: List<com.bobai.assistant.domain.model.OnboardingPermissionStatus>,
    providers: List<AiProviderConfig>,
    visionRoleProviderId: String,
    visionCallsToday: Int,
    assistantEnabled: Boolean,
    wakeWordActive: Boolean,
    continuousDialogue: Boolean,
    speechRate: Float,
    availableVoices: List<String>,
    selectedVoiceName: String,
    previewEnabled: Boolean,
    onRequestPermission: (String) -> Unit,
    onStartForegroundService: () -> Unit,
    onToggleAssistant: (Boolean) -> Unit,
    onToggleWakeWord: () -> Unit,
    onToggleContinuous: (Boolean) -> Unit,
    onSpeechRateChange: (Float) -> Unit,
    onSelectVoice: (String) -> Unit,
    onToggleScreenshotPreview: (Boolean) -> Unit,
    onEditProvider: (AiProviderConfig) -> Unit,
    onSelectVisionProvider: (String) -> Unit,
    getMaskedKey: (String) -> String
) {
    LazyColumn(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                "Мастер первоначальной настройки и разрешений",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color.White
            )
            Text(
                "BOB AI работает максимально полно при предоставлении системных разрешений ниже:",
                fontSize = 12.sp,
                color = Color(0xFF94A3B8)
            )
        }

        items(permissions, key = { it.id }) { perm ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF111622))
                    .border(1.dp, Color(0xFF1F293B), RoundedCornerShape(10.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(
                            imageVector = if (perm.granted) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (perm.granted) Color(0xFF10B981) else Color(0xFFF59E0B),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(perm.title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = Color.White)
                    }
                    OutlinedButton(onClick = { onRequestPermission(perm.id) }) {
                        Text(if (perm.granted) "Открыть" else "Разрешить", fontSize = 11.sp)
                    }
                }
                Text(perm.rationale, fontSize = 12.sp, color = Color(0xFF94A3B8))
                perm.oemHint?.let { hint ->
                    Text(hint, fontSize = 11.sp, color = Color(0xFFFBBF24))
                }
            }
        }

        item {
            Text("Голос и активация", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF111622))
                    .border(1.dp, Color(0xFF1F293B), RoundedCornerShape(10.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Режим ожидания «Привет, Боб»", fontSize = 13.sp, color = Color.White)
                        Text(
                            "Слушает фразу при открытом приложении/активной сессии (Android 12+ ограничивает фоновый микрофон).",
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                    Switch(checked = wakeWordActive, onCheckedChange = { onToggleWakeWord() })
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Непрерывный диалог после ответа", fontSize = 13.sp, color = Color.White)
                    Switch(checked = continuousDialogue, onCheckedChange = onToggleContinuous)
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Показывать последний скриншот Visual Agent", fontSize = 13.sp, color = Color.White)
                    Switch(checked = previewEnabled, onCheckedChange = onToggleScreenshotPreview)
                }

                Text("Скорость речи: ${"%.2f".format(speechRate)}x", fontSize = 12.sp, color = Color(0xFF94A3B8))
                Slider(value = speechRate, onValueChange = onSpeechRateChange, valueRange = 0.7f..1.6f)

                if (availableVoices.isNotEmpty()) {
                    Text("Русский голос TTS (${availableVoices.size} доступно):", fontSize = 12.sp, color = Color(0xFF94A3B8))
                    availableVoices.take(4).forEach { voiceName ->
                        OutlinedButton(
                            onClick = { onSelectVoice(voiceName) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (selectedVoiceName == voiceName) "✓ $voiceName" else voiceName,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        item {
            Text(
                "Мультимодальные модели и API-ключи (Vision AI: $visionCallsToday вызовов сегодня)",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color.White
            )
        }

        items(providers, key = { it.id }) { cfg ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF111622))
                    .border(1.dp, Color(0xFF1F293B), RoundedCornerShape(10.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(cfg.displayName, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = Color.White)
                Text(
                    "Модель: ${cfg.modelName} · Vision: ${if (cfg.supportsVision) "Да" else "Нет"} · Ключ: ${getMaskedKey(cfg.id).ifBlank { "не задан" }}",
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onEditProvider(cfg) }) {
                        Text("Настроить / Ключ", fontSize = 11.sp)
                    }
                    if (cfg.supportsVision) {
                        Button(onClick = { onSelectVisionProvider(cfg.id) }) {
                            Text(if (visionRoleProviderId == cfg.id) "✓ Visual AI" else "Выбрать для Vision", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onStartForegroundService, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Build, contentDescription = null)
                    Text(" Запустить фоновый сервис BOB AI")
                }
                Button(
                    onClick = { onToggleAssistant(!assistantEnabled) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (assistantEnabled) Color(0xFFEF4444) else Color(0xFF10B981)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (assistantEnabled) "Экстренно отключить помощника" else "Включить помощника обратно")
                }
            }
        }
    }
}

@Composable
private fun MemoryEditorDialog(
    onDismiss: () -> Unit,
    onSave: (category: String, key: String, content: String) -> Unit
) {
    var category by remember { mutableStateOf("preference") }
    var key by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Добавить запись в память") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Категория") }, singleLine = true)
                OutlinedTextField(value = key, onValueChange = { key = it }, label = { Text("Ключ") }, singleLine = true)
                OutlinedTextField(value = content, onValueChange = { content = it }, label = { Text("Содержимое") })
            }
        },
        confirmButton = {
            Button(onClick = { onSave(category, key, content) }, enabled = key.isNotBlank() && content.isNotBlank()) {
                Text("Сохранить")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}

@Composable
private fun ProviderEditorDialog(
    config: AiProviderConfig,
    maskedKey: String,
    onDismiss: () -> Unit,
    onSave: (AiProviderConfig, String?) -> Unit
) {
    var modelName by remember { mutableStateOf(config.modelName) }
    var baseUrl by remember { mutableStateOf(config.baseUrl) }
    var enabled by remember { mutableStateOf(config.enabled) }
    var supportsVision by remember { mutableStateOf(config.supportsVision) }
    var apiKey by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(config.displayName) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = modelName, onValueChange = { modelName = it }, label = { Text("Имя модели") }, singleLine = true)
                OutlinedTextField(value = baseUrl, onValueChange = { baseUrl = it }, label = { Text("Base URL") }, singleLine = true)
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    label = { Text("Новый API-ключ (текущий: ${maskedKey.ifBlank { "нет" }})") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Провайдер активен", fontSize = 13.sp)
                    Switch(checked = enabled, onCheckedChange = { enabled = it })
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Поддержка изображений (Vision)", fontSize = 13.sp)
                    Switch(checked = supportsVision, onCheckedChange = { supportsVision = it })
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        config.copy(
                            modelName = modelName.trim(),
                            baseUrl = baseUrl.trim(),
                            enabled = enabled,
                            supportsVision = supportsVision
                        ),
                        apiKey.trim().takeIf { it.isNotBlank() }
                    )
                }
            ) {
                Text("Сохранить")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}
