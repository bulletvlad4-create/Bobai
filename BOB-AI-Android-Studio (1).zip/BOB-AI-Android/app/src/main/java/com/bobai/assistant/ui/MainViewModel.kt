package com.bobai.assistant.ui

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.bobai.assistant.AppContainer
import com.bobai.assistant.data.local.ActionLogEntity
import com.bobai.assistant.data.local.ChatMessageEntity
import com.bobai.assistant.data.local.MemoryEntity
import com.bobai.assistant.domain.model.AiProviderConfig
import com.bobai.assistant.domain.model.AvatarState
import com.bobai.assistant.domain.model.ModelRole
import com.bobai.assistant.domain.model.OnboardingPermissionStatus
import com.bobai.assistant.domain.model.PipelineStatus
import com.bobai.assistant.voice.VoiceOption
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(private val container: AppContainer) : ViewModel() {

    val avatarState: StateFlow<AvatarState> = container.orchestrator.avatarState
    val pipeline: StateFlow<PipelineStatus> = container.orchestrator.pipeline
    val isListening: StateFlow<Boolean> = container.speechEngine.isListening
    val partialTranscript: StateFlow<String> = container.speechEngine.partialText
    val wakeWordModeActive: StateFlow<Boolean> = container.speechEngine.wakeWordModeActive
    val speechError: StateFlow<String?> = container.speechEngine.lastError
    val isSpeaking: StateFlow<Boolean> = container.voiceEngine.isSpeaking
    val availableVoices: StateFlow<List<VoiceOption>> = container.voiceEngine.availableVoices
    val hasMediaProjectionConsent: StateFlow<Boolean> = container.captureManager.hasMediaProjectionConsent
    val screenshotPreviewEnabled: StateFlow<Boolean> = container.captureManager.previewEnabled
    val lastPreviewBitmap: StateFlow<Bitmap?> = container.captureManager.lastPreviewBitmap

    val memories: StateFlow<List<MemoryEntity>> = container.memoryEngine.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val actionLogs: StateFlow<List<ActionLogEntity>> = container.dao.observeActionLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chatMessages: StateFlow<List<ChatMessageEntity>> = container.dao.observeChatMessages()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _permissions = MutableStateFlow<List<OnboardingPermissionStatus>>(emptyList())
    val permissions: StateFlow<List<OnboardingPermissionStatus>> = _permissions

    private val _providers = MutableStateFlow<List<AiProviderConfig>>(emptyList())
    val providers: StateFlow<List<AiProviderConfig>> = _providers

    private val _continuousDialogue = MutableStateFlow(true)
    val continuousDialogue: StateFlow<Boolean> = _continuousDialogue

    private val _speechRate = MutableStateFlow(container.voiceEngine.getRate())
    val speechRate: StateFlow<Float> = _speechRate

    private val _selectedVoiceName = MutableStateFlow(container.voiceEngine.getSelectedVoiceName())
    val selectedVoiceName: StateFlow<String> = _selectedVoiceName

    private val _assistantEnabled = MutableStateFlow(container.securityManager.assistantEnabled)
    val assistantEnabled: StateFlow<Boolean> = _assistantEnabled

    private val _visionCallsToday = MutableStateFlow(container.visionCostGuard.getTodayCount())
    val visionCallsToday: StateFlow<Int> = _visionCallsToday

    private val _visionRoleProviderId = MutableStateFlow(container.aiRouter.getRoleBinding(ModelRole.VISION_AGENT))
    val visionRoleProviderId: StateFlow<String> = _visionRoleProviderId

    init {
        refreshPermissions()
        refreshProviders()
    }

    fun refreshPermissions() {
        _permissions.value = container.toolSystem.getOnboardingPermissions()
    }

    fun refreshProviders() {
        _providers.value = container.aiRouter.listProviders()
        _visionCallsToday.value = container.visionCostGuard.getTodayCount()
        _visionRoleProviderId.value = container.aiRouter.getRoleBinding(ModelRole.VISION_AGENT)
    }

    fun getApiKeyMasked(providerId: String): String {
        val raw = container.keyStore.getApiKey(providerId)
        return if (raw.length <= 8) raw else "${raw.take(4)}••••${raw.takeLast(4)}"
    }

    fun submitCommand(text: String) {
        if (text.isBlank()) return
        container.voiceEngine.interruptImmediately()
        viewModelScope.launch {
            container.orchestrator.handleCommand(text.trim()) { reply ->
                speakAndContinue(reply)
            }
            _visionCallsToday.value = container.visionCostGuard.getTodayCount()
        }
    }

    private fun speakAndContinue(reply: String) {
        container.voiceEngine.speak(reply) {
            if (_continuousDialogue.value && !container.speechEngine.wakeWordModeActive.value) {
                startSingleListen()
            }
        }
    }

    fun toggleVoiceListening() {
        container.voiceEngine.interruptImmediately()
        if (container.speechEngine.isListening.value) {
            container.speechEngine.stopListening()
            return
        }
        startSingleListen()
    }

    private fun startSingleListen() {
        container.speechEngine.startListening(
            onFinalResult = { recognized -> submitCommand(recognized) },
            onError = { /* Статус отражается в speechError */ },
            onBargeInDetected = { container.voiceEngine.interruptImmediately() }
        )
    }

    fun toggleWakeWordMode() {
        if (container.speechEngine.wakeWordModeActive.value) {
            container.speechEngine.stopWakeWordLoop()
            return
        }
        container.speechEngine.startWakeWordLoop(
            onCommandExtracted = { command -> submitCommand(command) },
            onWakeOnlyDetected = {
                container.voiceEngine.speak("Слушаю вас!") {
                    startSingleListen()
                }
            },
            onBargeInDetected = { container.voiceEngine.interruptImmediately() },
            onStatusMessage = { /* Статус в speechError */ }
        )
    }

    fun setContinuousDialogue(enabled: Boolean) {
        _continuousDialogue.value = enabled
    }

    fun setSpeechRate(rate: Float) {
        container.voiceEngine.setRate(rate)
        _speechRate.value = container.voiceEngine.getRate()
    }

    fun setVoiceName(name: String) {
        container.voiceEngine.applyVoiceByName(name)
        _selectedVoiceName.value = name
    }

    fun setScreenshotPreviewEnabled(enabled: Boolean) {
        container.captureManager.setPreviewEnabled(enabled)
    }

    fun captureSinglePreviewFrame() {
        viewModelScope.launch {
            container.captureManager.captureFreshScreen()
        }
    }

    fun confirmPendingStep() {
        viewModelScope.launch {
            container.orchestrator.confirmPendingStep { reply ->
                speakAndContinue(reply)
            }
        }
    }

    fun rejectPendingStep() {
        viewModelScope.launch {
            container.orchestrator.rejectPendingStep { reply ->
                speakAndContinue(reply)
            }
        }
    }

    fun stopSpeaking() {
        container.voiceEngine.interruptImmediately()
    }

    fun cancelExecution() {
        container.orchestrator.cancelCurrentTask()
        container.voiceEngine.interruptImmediately()
        container.speechEngine.stopListening()
    }

    fun addOrUpdateMemory(category: String, key: String, content: String, importance: Int = 2) {
        if (key.isBlank() || content.isBlank()) return
        viewModelScope.launch {
            container.memoryEngine.save(category, key.trim(), content.trim(), importance)
        }
    }

    fun deleteMemory(id: String) {
        viewModelScope.launch {
            container.memoryEngine.remove(id)
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            container.dao.clearActionLogs()
        }
    }

    fun updateProvider(config: AiProviderConfig, apiKey: String?) {
        container.aiRouter.updateProvider(config, apiKey)
        refreshProviders()
    }

    fun bindModelRole(role: ModelRole, providerId: String) {
        container.aiRouter.bindRole(role, providerId)
        refreshProviders()
    }

    fun setAssistantEnabled(enabled: Boolean) {
        container.securityManager.assistantEnabled = enabled
        _assistantEnabled.value = enabled
    }

    class Factory(private val container: AppContainer) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = MainViewModel(container) as T
    }
}
