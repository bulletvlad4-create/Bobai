package com.bobai.assistant.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
@Entity(tableName = "memory_records")
data class MemoryEntity(
    @PrimaryKey val id: String,
    val category: String,
    val key: String,
    val content: String,
    val importance: Int,
    val usageCount: Int,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "action_logs")
data class ActionLogEntity(
    @PrimaryKey val id: String,
    val timestamp: Long,
    val command: String,
    val tool: String,
    val humanLabel: String,
    val paramsSummary: String,
    val status: String,
    val attempts: Int,
    val verified: Boolean,
    val details: String
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val role: String,
    val text: String,
    val heard: String?,
    val understood: String?,
    val modelUsed: String?,
    val timestamp: Long
)

@Dao
interface BobDao {
    @Query("SELECT * FROM memory_records ORDER BY importance DESC, updatedAt DESC")
    fun observeMemories(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memory_records WHERE key LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%' ORDER BY importance DESC")
    suspend fun searchMemories(query: String): List<MemoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMemory(record: MemoryEntity)

    @Query("DELETE FROM memory_records WHERE id = :id")
    suspend fun deleteMemory(id: String)

    @Query("SELECT * FROM action_logs ORDER BY timestamp DESC LIMIT 150")
    fun observeActionLogs(): Flow<List<ActionLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActionLog(log: ActionLogEntity)

    @Query("DELETE FROM action_logs")
    suspend fun clearActionLogs()

    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun observeChatMessages(): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChatMessage(message: ChatMessageEntity)
}

@Database(
    entities = [MemoryEntity::class, ActionLogEntity::class, ChatMessageEntity::class],
    version = 1,
    exportSchema = false
)
abstract class BobDatabase : RoomDatabase() {
    abstract fun dao(): BobDao

    companion object {
        @Volatile
        private var INSTANCE: BobDatabase? = null

        fun getInstance(context: Context): BobDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    BobDatabase::class.java,
                    "bob_ai_memory.db"
                ).build().also { INSTANCE = it }
            }
    }
}

class MemoryEngine(private val dao: BobDao) {
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }

    fun observeAll(): Flow<List<MemoryEntity>> = dao.observeMemories()

    suspend fun search(query: String): List<MemoryEntity> =
        if (query.isBlank()) dao.searchMemories("") else dao.searchMemories(query.trim())

    suspend fun save(category: String, key: String, content: String, importance: Int = 2) {
        val now = System.currentTimeMillis()
        val existing = dao.searchMemories(key).firstOrNull { it.key.equals(key, ignoreCase = true) }
        val entity = if (existing != null) {
            existing.copy(
                category = category,
                content = content,
                importance = importance,
                usageCount = existing.usageCount + 1,
                updatedAt = now
            )
        } else {
            MemoryEntity(
                id = "mem-$now",
                category = category,
                key = key,
                content = content,
                importance = importance,
                usageCount = 1,
                createdAt = now,
                updatedAt = now
            )
        }
        dao.upsertMemory(entity)
    }

    suspend fun remove(id: String) = dao.deleteMemory(id)

    suspend fun exportJson(): String = json.encodeToString(dao.searchMemories(""))

    suspend fun importJson(raw: String): Int {
        val items = json.decodeFromString<List<MemoryEntity>>(raw)
        items.forEach { dao.upsertMemory(it) }
        return items.size
    }
}
