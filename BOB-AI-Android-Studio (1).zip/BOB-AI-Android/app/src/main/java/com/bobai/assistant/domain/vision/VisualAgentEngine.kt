package com.bobai.assistant.domain.vision

import com.bobai.assistant.data.local.ActionLogEntity
import com.bobai.assistant.data.local.BobDao
import com.bobai.assistant.domain.model.ToolResult
import com.bobai.assistant.domain.model.VisualDecision
import com.bobai.assistant.domain.model.VisualStepTrace
import com.bobai.assistant.system.accessibility.BobAccessibilityService
import com.bobai.assistant.system.vision.OcrEngine
import com.bobai.assistant.system.vision.ScreenCaptureManager
import kotlinx.coroutines.delay

data class VisualGoalOutcome(
    val success: Boolean,
    val verified: Boolean,
    val message: String,
    val traces: List<VisualStepTrace>,
    val lastDecision: VisualDecision?
)

class VisualAgentEngine(
    private val captureManager: ScreenCaptureManager,
    private val ocrEngine: OcrEngine,
    private val visualRouter: VisualModelRouter,
    private val dao: BobDao
) {
    companion object {
        const val DEFAULT_MAX_STEPS = 12
        const val DEFAULT_MAX_DURATION_MS = 90_000L
    }

    @Volatile
    private var cancelled = false

    fun cancel() {
        cancelled = true
    }

    suspend fun executeVisualGoal(
        goal: String,
        maxSteps: Int = DEFAULT_MAX_STEPS,
        maxDurationMs: Long = DEFAULT_MAX_DURATION_MS,
        isSensitiveActionGuard: (VisualDecision) -> String?,
        onProgress: (
            phase: String,
            stepCount: Int,
            decision: VisualDecision?,
            trace: VisualStepTrace?
        ) -> Unit
    ): VisualGoalOutcome {
        cancelled = false
        val accessibility = BobAccessibilityService.instance
            ?: return VisualGoalOutcome(
                success = false,
                verified = false,
                message = "Для выполнения визуальных жестов необходимо включить AccessibilityService Боба.",
                traces = emptyList(),
                lastDecision = null
            )

        if (!captureManager.hasMediaProjectionConsent.value && android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.R) {
            return VisualGoalOutcome(
                success = false,
                verified = false,
                message = "Требуется системное разрешение MediaProjection на захват экрана.",
                traces = emptyList(),
                lastDecision = null
            )
        }

        val startedAt = System.currentTimeMillis()
        val traces = mutableListOf<VisualStepTrace>()
        val stepHistory = mutableListOf<String>()
        var lastHash: Long? = null
        var stagnationCount = 0
        var consecutiveErrors = 0
        var lastDecision: VisualDecision? = null

        for (stepIdx in 1..maxSteps) {
            if (cancelled) {
                return VisualGoalOutcome(false, false, "Визуальное выполнение остановлено пользователем.", traces, lastDecision)
            }
            if (System.currentTimeMillis() - startedAt > maxDurationMs) {
                return VisualGoalOutcome(false, false, "Превышен лимит времени визуального агента (${maxDurationMs / 1000}с).", traces, lastDecision)
            }

            // 1. SCREENSHOT
            onProgress("Скриншот экрана...", stepIdx, lastDecision, null)
            val frame = captureManager.captureFreshScreen()
            if (frame == null) {
                return VisualGoalOutcome(
                    success = false,
                    verified = false,
                    message = "Не удалось получить скриншот. Предоставьте разрешение MediaProjection в разделе «Система».",
                    traces = traces,
                    lastDecision = lastDecision
                )
            }

            if (frame.isProtectedFlagSecure) {
                return VisualGoalOutcome(
                    success = false,
                    verified = false,
                    message = "Экран защищён системой (FLAG_SECURE). Android запрещает захват содержимого этого приложения.",
                    traces = traces,
                    lastDecision = lastDecision
                )
            }

            // Track stagnation across screenshots
            if (lastHash != null && frame.perceptualHash == lastHash) {
                stagnationCount++
            } else {
                stagnationCount = 0
            }
            lastHash = frame.perceptualHash

            // 2. OCR + ACCESSIBILITY TREE
            onProgress("OCR и дерево Accessibility...", stepIdx, lastDecision, null)
            val ocrBlocks = ocrEngine.extractTextBlocks(frame.bitmap, frame.screenWidth, frame.screenHeight)
            val ocrSummary = ocrEngine.formatOcrSummary(ocrBlocks)
            val accSummary = accessibility.formatTreeSummary()

            // 3. AI VISION DECISION
            onProgress("Анализ изображения моделью ИИ...", stepIdx, lastDecision, null)
            val (decision, modelName) = try {
                val hint = if (stagnationCount >= 2) {
                    stepHistory + "ВНИМАНИЕ: предыдущий шаг не изменил экран, выбери альтернативный элемент или прокрути."
                } else {
                    stepHistory
                }
                visualRouter.analyzeWithFallback(
                    imageBase64 = frame.base64Jpeg,
                    mimeType = frame.mimeType,
                    imageWidth = frame.imageWidth,
                    imageHeight = frame.imageHeight,
                    screenWidth = frame.screenWidth,
                    screenHeight = frame.screenHeight,
                    userGoal = goal,
                    accessibilitySummary = accSummary,
                    ocrSummary = ocrSummary,
                    stepHistory = hint
                )
            } catch (t: Throwable) {
                consecutiveErrors++
                if (consecutiveErrors >= 3) {
                    return VisualGoalOutcome(false, false, "Сбой Visual AI: ${t.message}", traces, lastDecision)
                }
                delay(700L)
                continue
            }

            consecutiveErrors = 0
            lastDecision = decision
            frame.bitmap.recycle()

            if (decision.screenProtected) {
                return VisualGoalOutcome(
                    success = false,
                    verified = false,
                    message = "Визуальная модель обнаружила защищённый системой экран.",
                    traces = traces,
                    lastDecision = decision
                )
            }

            if (decision.goalAchieved || decision.action == "done") {
                val doneTrace = VisualStepTrace(
                    stepIndex = stepIdx,
                    phase = "VERIFIED",
                    action = "done",
                    reason = decision.reason.ifBlank { decision.screenDescription },
                    confidence = decision.confidence,
                    screenX = null,
                    screenY = null,
                    verified = true,
                    message = "Цель подтверждена на экране ($modelName)."
                )
                traces.add(doneTrace)
                onProgress("Цель подтверждена", stepIdx, decision, doneTrace)
                return VisualGoalOutcome(
                    success = true,
                    verified = true,
                    message = decision.reason.ifBlank { decision.screenDescription },
                    traces = traces,
                    lastDecision = decision
                )
            }

            if (decision.action == "abort") {
                return VisualGoalOutcome(
                    success = false,
                    verified = false,
                    message = "Визуальный агент остановился: ${decision.reason}",
                    traces = traces,
                    lastDecision = decision
                )
            }

            // 4. SECURITY GATE FOR SENSITIVE VISUAL TARGETS
            val securityBlockReason = isSensitiveActionGuard(decision)
            if (securityBlockReason != null) {
                return VisualGoalOutcome(
                    success = false,
                    verified = false,
                    message = "Операция остановлена системой безопасности: $securityBlockReason",
                    traces = traces,
                    lastDecision = decision
                )
            }

            // 5. EXECUTE HYBRID ACTION (Accessibility Tree + dispatchGesture Coordinates)
            val screenPoint = VisualDecisionValidator.toScreenPixels(
                coords = decision.coordinates,
                imageWidth = frame.imageWidth,
                imageHeight = frame.imageHeight,
                screenWidth = frame.screenWidth,
                screenHeight = frame.screenHeight
            )
            onProgress("Выполнение: ${decision.action}...", stepIdx, decision, null)

            val actionResult = performHybridAction(
                accessibility = accessibility,
                decision = decision,
                screenPoint = screenPoint,
                imageWidth = frame.imageWidth,
                imageHeight = frame.imageHeight,
                screenWidth = frame.screenWidth,
                screenHeight = frame.screenHeight,
                preferAlternative = stagnationCount >= 2
            )

            val trace = VisualStepTrace(
                stepIndex = stepIdx,
                phase = "ACTION",
                action = decision.action,
                reason = decision.reason,
                confidence = decision.confidence,
                screenX = screenPoint?.first,
                screenY = screenPoint?.second,
                verified = actionResult.verified,
                message = actionResult.message
            )
            traces.add(trace)
            stepHistory.add("Шаг $stepIdx (${decision.action}): ${decision.reason} -> ${actionResult.message}")

            dao.insertActionLog(
                ActionLogEntity(
                    id = "vlog-${System.currentTimeMillis()}-$stepIdx",
                    timestamp = System.currentTimeMillis(),
                    command = goal,
                    tool = "visual_${decision.action}",
                    humanLabel = decision.reason.ifBlank { "Визуальный шаг ${decision.action}" },
                    paramsSummary = "x=${screenPoint?.first ?: "-"}, y=${screenPoint?.second ?: "-"}, target=${decision.targetText}",
                    status = if (actionResult.success) "COMPLETED" else "FAILED",
                    attempts = 1,
                    verified = actionResult.verified,
                    details = "${decision.screenDescription} | ${actionResult.message}"
                )
            )
            onProgress("Проверка результата...", stepIdx, decision, trace)

            // Wait for UI transition before capturing verification screenshot
            delay(if (decision.action == "wait") 1400L else 850L)
        }

        return VisualGoalOutcome(
            success = false,
            verified = false,
            message = "Достигнут лимит шагов Visual Agent ($maxSteps). Текущий экран: ${lastDecision?.screenDescription ?: "неизвестно"}.",
            traces = traces,
            lastDecision = lastDecision
        )
    }

    private suspend fun performHybridAction(
        accessibility: BobAccessibilityService,
        decision: VisualDecision,
        screenPoint: Pair<Int, Int>?,
        imageWidth: Int,
        imageHeight: Int,
        screenWidth: Int,
        screenHeight: Int,
        preferAlternative: Boolean
    ): ToolResult {
        return when (decision.action) {
            "tap" -> {
                var ok = false
                var method = "dispatchGesture"
                if (!preferAlternative && decision.targetText.isNotBlank()) {
                    ok = accessibility.clickByQuery(decision.targetText)
                    if (ok) method = "Accessibility query"
                }
                if (!ok && screenPoint != null) {
                    val nodeAtPt = accessibility.findNodeAtCoordinates(screenPoint.first, screenPoint.second)
                    if (!preferAlternative && nodeAtPt != null && nodeAtPt.clickable) {
                        ok = accessibility.clickByQuery(nodeAtPt.text.ifBlank { nodeAtPt.contentDescription })
                        if (ok) method = "Accessibility node@coords"
                    }
                    if (!ok) {
                        ok = accessibility.tapAt(screenPoint.first, screenPoint.second)
                        method = "dispatchGesture(${screenPoint.first},${screenPoint.second})"
                    }
                }
                ToolResult(ok, ok, if (ok) "Нажатие выполнено ($method)" else "Не удалось выполнить нажатие")
            }

            "double_tap" -> {
                val pt = screenPoint ?: return ToolResult(false, false, "Нет координат для двойного нажатия")
                val ok = accessibility.doubleTapAt(pt.first, pt.second)
                ToolResult(ok, ok, if (ok) "Двойное нажатие @ (${pt.first},${pt.second})" else "Ошибка двойного нажатия")
            }

            "long_press" -> {
                val pt = screenPoint ?: return ToolResult(false, false, "Нет координат для долгого нажатия")
                val ok = accessibility.longPressAt(pt.first, pt.second)
                ToolResult(ok, ok, if (ok) "Долгое нажатие @ (${pt.first},${pt.second})" else "Ошибка долгого нажатия")
            }

            "swipe" -> {
                val pts = VisualDecisionValidator.toScreenSwipePoints(
                    coords = decision.coordinates,
                    imageWidth = imageWidth,
                    imageHeight = imageHeight,
                    screenWidth = screenWidth,
                    screenHeight = screenHeight
                )
                val ok = if (pts != null) {
                    accessibility.swipe(pts.first.first, pts.first.second, pts.second.first, pts.second.second)
                } else {
                    accessibility.scrollGesture(decision.scrollDirection, screenWidth, screenHeight)
                }
                ToolResult(ok, ok, if (ok) "Свайп выполнен" else "Не удалось выполнить свайп")
            }

            "scroll" -> {
                val forward = decision.scrollDirection.lowercase() in setOf("down", "right")
                val okSemantic = if (!preferAlternative) accessibility.scrollSemantic(forward) else false
                val ok = if (okSemantic) true else accessibility.scrollGesture(decision.scrollDirection, screenWidth, screenHeight)
                ToolResult(ok, ok, if (ok) "Прокрутка (${decision.scrollDirection})" else "Ошибка прокрутки")
            }

            "input_text" -> {
                if (screenPoint != null) {
                    accessibility.tapAt(screenPoint.first, screenPoint.second)
                    delay(280L)
                }
                val ok = accessibility.inputText(decision.targetText, decision.inputText)
                ToolResult(ok, ok, if (ok) "Введён текст «${decision.inputText}»" else "Поле ввода не приняло текст")
            }

            "back" -> {
                val ok = accessibility.navigateBack()
                ToolResult(ok, ok, if (ok) "Возврат назад" else "Ошибка возврата назад")
            }

            "wait" -> ToolResult(true, true, "Ожидание обновления интерфейса")
            else -> ToolResult(false, false, "Неподдерживаемое действие: ${decision.action}")
        }
    }
}
