package com.bobai.assistant.system.vpn

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.bobai.assistant.MainActivity

class BobVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.bobai.assistant.vpn.START"
        const val ACTION_STOP = "com.bobai.assistant.vpn.STOP"
        const val CHANNEL_ID = "bob_ai_vpn_channel"
        const val NOTIFICATION_ID = 1003

        @Volatile
        var isRunning: Boolean = false
            private set
    }

    private var vpnInterface: ParcelFileDescriptor? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "BOB AI VPN-туннель",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return when (intent?.action) {
            ACTION_STOP -> {
                stopVpnTunnel()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                START_NOT_STICKY
            }
            else -> {
                startVpnTunnel()
                START_STICKY
            }
        }
    }

    private fun startVpnTunnel() {
        if (vpnInterface != null) return
        val openIntent = PendingIntent.getActivity(
            this,
            21,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            22,
            Intent(this, BobVpnService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("BOB AI — Локальный VPN-туннель активен")
            .setContentText("DNS 1.1.1.1 · Локальный интерфейс 10.8.0.2")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Отключить", stopIntent)
            .build()

        runCatching {
            startForeground(NOTIFICATION_ID, notification)
            val builder = Builder()
                .setSession("BOB AI Local Tunnel")
                .addAddress("10.8.0.2", 32)
                .addDnsServer("1.1.1.1")
                .setMtu(1400)
            vpnInterface = builder.establish()
            isRunning = vpnInterface != null
            if (!isRunning) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }.onFailure {
            isRunning = false
        }
    }

    private fun stopVpnTunnel() {
        runCatching { vpnInterface?.close() }
        vpnInterface = null
        isRunning = false
    }

    override fun onDestroy() {
        stopVpnTunnel()
        super.onDestroy()
    }
}
