package com.bobai.assistant.domain.agent

import com.bobai.assistant.data.local.ActionLogEntity
import com.bobai.assistant.data.local.BobDao
import com.bobai.assistant.data.local.ChatMessageEntity
import com.bobai.assistant.data.local.MemoryEngine
import com.bobai.assistant.domain.brain.JsonExtractionUtils
import com.bobai.assistant.domain.brain.UniversalAiRouter
import com.bobai.assistant.domain.model.AgentPlanResponse
import com.bobai.assistant.domain.model.AvatarState
import com.bobai.assistant.domain.model.ModelRole
import com.bobai.assistant.domain.model.PipelineStatus
import com.bobai.assistant.domain.model.PlannedStep
import com.bobai.assistant.domain.model.RiskLevel
import com.bobai.assistant.domain.model.ToolResult
import com.bobai.assistant.domain.model.VisualDecision
import com.bobai.assistant.domain.vision.VisualAgentEngine
import com.bobai.assistant.system.ToolSystem
import com.bobai.assistant.system.accessibility.BobAccessibilityService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.json.Json

class SecurityManager {
    private val criticalTools = setOf("delete_file", "send_message", "share_file")
    private val elevatedTools = setOf("toggle_vpn", "toggle_dnd", "visual_goal")
    private val criticalKeywords = listOf(
        "удал", "стерет", "очист", "перевед", "оплат", "покуп", "куп",
        "отправ", "карта", "сбер", "банк", "парол", "код из смс", "пин"
    )

    @Volatile
    var assistantEnabled: Boolean = true

    val disabledTools = mutableSetOf<String>()

    fun assessRisk(step: PlannedStep, rawCommand: String): RiskLevel {
        if (step.tool in criticalTools) return RiskLevel.CRITICAL
        val joined = "$rawCommand ${step.humanLabel} ${step.params.values.joinToString(" ")}".lowercase()
        if (criticalKeywords.any { joined.contains(it) } &&
            (step.tool.startsWith("accessibility_") || step.tool == "visual_goal")
        ) {
            return RiskLevel.CRITICAL
        }
        if (step.tool in elevatedTools) return RiskLevel.ELEVATED
        return RiskLevel.SAFE
    }

    fun inspectVisualDecisionForRisk(decision: VisualDecision): String? {
        val text = "${decision.targetText} ${decision.inputText} ${decision.reason} ${decision.screenDescription}".lowercase()
        val forbidden = listOf("удал", "перевести", "оплатить", "купить", "подтвердить списание", "отправить всем")
        val hit = forbidden.firstOrNull { text.contains(it) }
        return if (hit != null) {
            "Обнаружено критическое действие на экране («$hit»), требующее ручного подтверждения."
        } else null
    }

    fun isAllowed(tool: String): Boolean = assistantEnabled && tool !in disabledTools
}

class ContextManager {
    private val recentTurns = ArrayDeque<String>(20)

    @Synchronized
    fun appendTurn(speaker: String, text: String) {
        if (recentTurns.size >= 20) recentTurns.removeFirst()
        recentTurns.addLast("$speaker: $text")
    }

    @Synchronized
    fun getSnapshot(): String = recentTurns.joinToString("\n")
}

object SelfCorrectionNormalizer {
    private val markers = listOf("да нет, лучше", "нет, лучше", "ой, сначала", "точнее,", "точнее ", "а не, ")

    fun normalize(rawCommand: String): String {
        val lower = rawCommand.lowercase()
        for (marker in markers) {
            val idx = lower.lastIndexOf(marker)
            if (idx >= 0) {
                val tail = rawCommand.substring(idx + marker.length).trim()
                if (tail.length >= 4) return tail
            }
        }
        return rawCommand.trim()
    }
}

class AiBrain(private val router: UniversalAiRouter) {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    suspend fun plan(
        userCommand: String,
        contextSnapshot: String,
        memorySummary: String,
        installedAppsSummary: String,
        accessibilitySummary: String,
        feedbackFromFailure: String? = null
    ): Pair<AgentPlanResponse, String> {
        val systemPrompt = """
            Ты — BOB AI, универсальный автономный голосовой и визуальный ИИ-агент для Android.
            Понимай естественную русскую речь, неполные фразы, сленг и самоисправления ("открой игру, да нет, лучше сначала включи VPN").
            Доступные инструменты (tool -> params):
            - launch_app: {"appName":"..."}
            - open_settings: {"section":"wifi|bluetooth|vpn|display|sound|accessibility|notifications|battery|main"}
            - set_volume: {"level":"0..100"}
            - set_brightness: {"level":"5..100"}
            - toggle_flashlight: {"enabled":"true|false"}
            - toggle_dnd: {"enabled":"true|false"}
            - toggle_wifi: {}
            - toggle_bluetooth: {"enabled":"true|false"}
            - check_network: {}
            - toggle_vpn: {"enabled":"true|false","client":"BobVpnService|WireGuard|..."}
            - media_control: {"action":"play|pause|next|previous|toggle"}
            - read_notifications: {"limit":"10"}
            - search_files: {"query":"..."}
            - open_file: {"query":"..."}
            - share_file: {"query":"..."}
            - delete_file: {"query":"..."}
            - create_note: {"title":"...","content":"..."}
            - save_memory: {"category":"preference|fact|app|task","key":"...","content":"..."}
            - accessibility_inspect: {}
            - accessibility_tap: {"target":"..."}
            - accessibility_input: {"target":"...","text":"..."}
            - accessibility_back: {}
            - visual_goal: {"goal":"подробная цель на текущем или открытом экране, например: найди чат с Алексеем и открой его"}

            Правило: если задача требует взаимодействия с интерфейсом внешнего приложения (Telegram, браузер, YouTube, Настройки Bluetooth и т.п.), сначала открой приложение через launch_app (или настройки), а затем добавь шаг visual_goal с точной целью для Visual Agent (Screenshot -> AI Vision -> Action -> Verification)!
            Отвечай СТРОГО JSON-объектом AgentPlanResponse:
            {"heard":"...","understood":"...","reply":"...","steps":[{"id":"1","tool":"...","params":{},"humanLabel":"...","rationale":"..."}],"memoryUpdates":[],"sources":[]}
        """.trimIndent()

        val feedbackBlock = if (!feedbackFromFailure.isNullOrBlank()) {
            "\nОБРАТНАЯ СВЯЗЬ ОТ ПРЕДЫДУЩЕЙ ПОПЫТКИ (ПЕРЕСТРОЙ ПЛАН):\n$feedbackFromFailure"
        } else ""

        val userPrompt = """
            Команда: $userCommand
            Нормализованный фокус: ${SelfCorrectionNormalizer.normalize(userCommand)}
            Память: ${memorySummary.ifBlank { "пусто" }}
            Установленные приложения: ${installedAppsSummary.ifBlank { "неизвестно" }}
            Текущий экран Accessibility: ${accessibilitySummary.ifBlank { "вне активного окна или недоступно" }}
            Контекст диалога: $contextSnapshot$feedbackBlock
        """.trimIndent()

        val (raw, modelName) = router.executeWithFallback(
            role = ModelRole.COMPLEX_PLANNING,
            systemPrompt = systemPrompt,
            userPrompt = userPrompt
        )
        val cleaned = JsonExtractionUtils.extractJsonObject(raw)
        return json.decodeFromString<AgentPlanResponse>(cleaned) to modelName
    }
}

class ActionExecutor(
    private val tools: ToolSystem,
    private val memoryEngine: MemoryEngine,
    private val visualAgent: VisualAgentEngine,
    private val security: SecurityManager,
    private val dao: BobDao
) {
    suspend fun executeStep(
        command: String,
        step: PlannedStep,
        onVisualProgress: (phase: String, stepCount: Int, decision: VisualDecision?) -> Unit
    ): ToolResult {
        if (!security.isAllowed(step.tool)) {
            val blocked = ToolResult(false, false, "Инструмент «${step.humanLabel}» отключён пользователем.")
            log(command, step, "BLOCKED", 1, blocked)
            return blocked
        }

        var attempt = 0
        var lastResult = ToolResult(false, false, "Не выполнено")
        val maxAttempts = if (step.tool == "visual_goal") 1 else (step.maxRetries.coerceIn(0, 3) + 1)

        while (attempt < maxAttempts) {
            attempt++
            lastResult = dispatchTool(step, onVisualProgress)
            if (lastResult.success) {
                log(command, step, "COMPLETED", attempt, lastResult)
                return lastResult
            }
        }
        log(command, step, "FAILED", attempt, lastResult)
        return lastResult
    }

    private suspend fun dispatchTool(
        step: PlannedStep,
        onVisualProgress: (phase: String, stepCount: Int, decision: VisualDecision?) -> Unit
    ): ToolResult {
        val p = step.params
        return when (step.tool) {
            "launch_app" -> tools.launchApp(p["appName"].orEmpty())
            "open_settings" -> tools.openSettings(p["section"] ?: "main")
            "set_volume" -> tools.setMediaVolume(p["level"]?.toIntOrNull() ?: 50)
            "set_brightness" -> tools.setBrightness(p["level"]?.toIntOrNull() ?: 70)
            "toggle_flashlight" -> tools.toggleFlashlight(p["enabled"]?.toBooleanStrictOrNull() ?: true)
            "toggle_dnd" -> tools.toggleDnd(p["enabled"]?.toBooleanStrictOrNull() ?: true)
            "toggle_wifi" -> tools.openWifiPanel()
            "toggle_bluetooth" -> tools.manageBluetooth(p["enabled"]?.toBooleanStrictOrNull() ?: true)
            "check_network" -> tools.checkNetwork()
            "toggle_vpn" -> tools.toggleVpn(
                enabled = p["enabled"]?.toBooleanStrictOrNull() ?: true,
                clientHint = p["client"].orEmpty()
            )
            "media_control" -> tools.controlMedia(p["action"] ?: "toggle")
            "read_notifications" -> tools.readRecentNotifications(p["limit"]?.toIntOrNull() ?: 10)
            "search_files" -> {
                val files = tools.searchFiles(p["query"].orEmpty())
                ToolResult(
                    success = files.isNotEmpty(),
                    verified = true,
                    message = if (files.isEmpty()) "Файлы не найдены." else "Найдено файлов: ${files.size} (первый: ${files.first().name}).",
                    data = files.joinToString("\n") { "${it.name} (${it.path})" }
                )
            }
            "open_file" -> tools.openFile(p["query"].orEmpty())
            "share_file" -> tools.shareFile(p["query"].orEmpty())
            "delete_file" -> tools.deleteAppFile(p["query"] ?: p["fileName"].orEmpty())
            "create_note" -> tools.createNoteFile(p["title"] ?: "Заметка", p["content"].orEmpty())
            "save_memory" -> {
                val k = p["key"].orEmpty().ifBlank { "Заметка" }
                val c = p["content"].orEmpty()
                memoryEngine.save(p["category"] ?: "fact", k, c, 2)
                ToolResult(true, true, "Сохранено в память: $k")
            }
            "accessibility_inspect" -> tools.inspectAccessibility()
            "accessibility_tap" -> tools.accessibilityTap(p["target"].orEmpty())
            "accessibility_input" -> tools.accessibilityInput(p["target"].orEmpty(), p["text"].orEmpty())
            "accessibility_back" -> tools.accessibilityBack()
            "visual_goal" -> {
                val goal = p["goal"].orEmpty().ifBlank { step.humanLabel }
                val outcome = visualAgent.executeVisualGoal(
                    goal = goal,
                    isSensitiveActionGuard = { decision -> security.inspectVisualDecisionForRisk(decision) },
                    onProgress = { phase, count, decision, _ ->
                        onVisualProgress(phase, count, decision)
                    }
                )
                ToolResult(outcome.success, outcome.verified, outcome.message)
            }
            else -> ToolResult(false, false, "Неизвестный инструмент: ${step.tool}")
        }
    }

    private suspend fun log(
        command: String,
        step: PlannedStep,
        status: String,
        attempts: Int,
        result: ToolResult
    ) {
        dao.insertActionLog(
            ActionLogEntity(
                id = "log-${System.currentTimeMillis()}-${step.id}",
                timestamp = System.currentTimeMillis(),
                command = command,
                tool = step.tool,
                humanLabel = step.humanLabel,
                paramsSummary = step.params.entries.joinToString { "${it.key}=${it.value}" },
                status = status,
                attempts = attempts,
                verified = result.verified,
                details = result.message
            )
        )
    }
}

class BobAgentOrchestrator(
    private val aiBrain: AiBrain,
    private val executor: ActionExecutor,
    private val memoryEngine: MemoryEngine,
    private val contextManager: ContextManager,
    private val securityManager: SecurityManager,
    private val toolSystem: ToolSystem,
    private val visualAgent: VisualAgentEngine,
    private val dao: BobDao
) {
    private val _avatarState = MutableStateFlow(AvatarState.IDLE)
    val avatarState: StateFlow<AvatarState> = _avatarState

    private val _pipeline = MutableStateFlow(PipelineStatus())
    val pipeline: StateFlow<PipelineStatus> = _pipeline

    @Volatile
    private var cancelled = false

    private var pendingQueueCommand: String? = null
    private var pendingQueueSteps: List<PlannedStep> = emptyList()
    private var pendingPlanReply: String = ""
    private var pendingModelUsed: String = ""
    private var pendingCompletedList: MutableList<String> = mutableListOf()

    fun cancelCurrentTask() {
        cancelled = true
        visualAgent.cancel()
        pendingQueueCommand = null
        pendingQueueSteps = emptyList()
        _pipeline.value = _pipeline.value.copy(
            currentlyExecuting = "Остановлено пользователем",
            awaitingConfirmation = null,
            isAnalyzingScreen = false,
            visualPhase = ""
        )
        _avatarState.value = AvatarState.IDLE
    }

    suspend fun confirmPendingStep(onSpeak: (String) -> Unit) {
        val step = _pipeline.value.awaitingConfirmation ?: return
        val cmd = pendingQueueCommand ?: step.humanLabel
        val remaining = pendingQueueSteps
        _pipeline.value = _pipeline.value.copy(awaitingConfirmation = null)

        val approvedOutcome = executeSingleStepWithUi(cmd, step)
        pendingCompletedList.add("${step.humanLabel}: ${approvedOutcome.message}")
        _pipeline.value = _pipeline.value.copy(
            completedSteps = pendingCompletedList.toList(),
            isAnalyzingScreen = false
        )

        continueRemainingQueue(cmd, remaining, pendingPlanReply, pendingModelUsed, onSpeak)
    }

    suspend fun rejectPendingStep(onSpeak: (String) -> Unit) {
        val step = _pipeline.value.awaitingConfirmation ?: return
        val cmd = pendingQueueCommand ?: step.humanLabel
        pendingCompletedList.add("${step.humanLabel}: Отменено пользователем")
        dao.insertActionLog(
            ActionLogEntity(
                id = "rej-${System.currentTimeMillis()}",
                timestamp = System.currentTimeMillis(),
                command = cmd,
                tool = step.tool,
                humanLabel = step.humanLabel,
                paramsSummary = step.params.toString(),
                status = "CANCELLED",
                attempts = 0,
                verified = false,
                details = "Отклонено пользователем на этапе подтверждения"
            )
        )
        pendingQueueCommand = null
        pendingQueueSteps = emptyList()
        _pipeline.value = _pipeline.value.copy(
            awaitingConfirmation = null,
            currentlyExecuting = "",
            completedSteps = pendingCompletedList.toList()
        )
        val msg = "Хорошо, действие «${step.humanLabel}» отменено."
        _avatarState.value = AvatarState.SPEAKING
        onSpeak(msg)
    }

    suspend fun handleCommand(
        command: String,
        onSpeak: (String) -> Unit
    ) {
        cancelled = false
        pendingCompletedList.clear()
        _avatarState.value = AvatarState.PROCESSING
        _pipeline.value = PipelineStatus(heard = command, errorBanner = null)
        contextManager.appendTurn("Пользователь", command)
        dao.insertChatMessage(
            ChatMessageEntity(
                id = "u-${System.currentTimeMillis()}",
                role = "user",
                text = command,
                heard = command,
                understood = null,
                modelUsed = null,
                timestamp = System.currentTimeMillis()
            )
        )

        try {
            val memories = memoryEngine.search("").take(20).joinToString("\n") { "${it.key} [${it.category}]: ${it.content}" }
            val apps = toolSystem.listInstalledApps().take(40).joinToString { it.label }
            val accSummary = BobAccessibilityService.instance?.formatTreeSummary(20).orEmpty()

            val (plan, modelName) = aiBrain.plan(
                userCommand = command,
                contextSnapshot = contextManager.getSnapshot(),
                memorySummary = memories,
                installedAppsSummary = apps,
                accessibilitySummary = accSummary
            )

            plan.memoryUpdates.forEach { m ->
                memoryEngine.save(m.category, m.key, m.content, m.importance)
            }

            _pipeline.value = _pipeline.value.copy(
                heard = plan.heard,
                understood = plan.understood,
                lastModelUsed = modelName
            )

            continueRemainingQueue(command, plan.steps, plan.reply, modelName, onSpeak, allowReplan = true)
        } catch (t: Throwable) {
            _avatarState.value = AvatarState.ERROR
            _pipeline.value = _pipeline.value.copy(
                currentlyExecuting = "",
                isAnalyzingScreen = false,
                errorBanner = t.message ?: "Неизвестная ошибка выполнения"
            )
        }
    }

    private suspend fun continueRemainingQueue(
        command: String,
        steps: List<PlannedStep>,
        planReply: String,
        modelName: String,
        onSpeak: (String) -> Unit,
        allowReplan: Boolean = false
    ) {
        var replannedOnce = !allowReplan
        var queue = steps.toMutableList()
        var stepLimit = 14

        while (queue.isNotEmpty() && stepLimit > 0) {
            if (cancelled) return
            stepLimit--
            val step = queue.removeAt(0)
            val risk = securityManager.assessRisk(step, command)
            if (risk == RiskLevel.CRITICAL) {
                pendingQueueCommand = command
                pendingQueueSteps = queue.toList()
                pendingPlanReply = planReply
                pendingModelUsed = modelName
                _pipeline.value = _pipeline.value.copy(
                    awaitingConfirmation = step.copy(
                        confirmationPrompt = step.confirmationPrompt
                            ?: "Подтвердите критическое действие: «${step.humanLabel}»"
                    )
                )
                _avatarState.value = AvatarState.IDLE
                return
            }

            val outcome = executeSingleStepWithUi(command, step)
            pendingCompletedList.add("${step.humanLabel}: ${outcome.message}")
            _pipeline.value = _pipeline.value.copy(
                currentlyExecuting = "",
                isAnalyzingScreen = false,
                visualPhase = "",
                completedSteps = pendingCompletedList.toList()
            )

            // Feedback loop: if a critical step fails, ask AiBrain once to adapt/replan
            if (!outcome.success && !replannedOnce && !cancelled) {
                replannedOnce = true
                _avatarState.value = AvatarState.PROCESSING
                val memories = memoryEngine.search("").take(15).joinToString("\n") { "${it.key}: ${it.content}" }
                val apps = toolSystem.listInstalledApps().take(30).joinToString { it.label }
                val accSummary = BobAccessibilityService.instance?.formatTreeSummary(20).orEmpty()
                val feedback = "Шаг «${step.humanLabel}» (${step.tool}) завершился неудачей: ${outcome.message}. Предложи альтернативные шаги (например, через visual_goal или open_settings)."
                val (newPlan, _) = aiBrain.plan(
                    userCommand = command,
                    contextSnapshot = contextManager.getSnapshot(),
                    memorySummary = memories,
                    installedAppsSummary = apps,
                    accessibilitySummary = accSummary,
                    feedbackFromFailure = feedback
                )
                if (newPlan.steps.isNotEmpty()) {
                    queue = newPlan.steps.toMutableList()
                }
            }
        }

        pendingQueueCommand = null
        pendingQueueSteps = emptyList()
        val finalReply = if (pendingCompletedList.isNotEmpty()) {
            planReply
        } else {
            planReply
        }
        contextManager.appendTurn("Боб", finalReply)
        dao.insertChatMessage(
            ChatMessageEntity(
                id = "a-${System.currentTimeMillis()}",
                role = "assistant",
                text = finalReply,
                heard = _pipeline.value.heard,
                understood = _pipeline.value.understood,
                modelUsed = modelName,
                timestamp = System.currentTimeMillis()
            )
        )
        _avatarState.value = AvatarState.SPEAKING
        onSpeak(finalReply)
    }

    private suspend fun executeSingleStepWithUi(command: String, step: PlannedStep): ToolResult {
        _avatarState.value = if (step.tool == "visual_goal") AvatarState.ANALYZING_SCREEN else AvatarState.EXECUTING
        _pipeline.value = _pipeline.value.copy(
            currentlyExecuting = step.humanLabel,
            isAnalyzingScreen = step.tool == "visual_goal"
        )
        return executor.executeStep(command, step) { phase, stepCount, decision ->
            _avatarState.value = AvatarState.ANALYZING_SCREEN
            _pipeline.value = _pipeline.value.copy(
                isAnalyzingScreen = true,
                visualPhase = phase,
                visualStepCount = stepCount,
                lastVisualDecision = decision
            )
        }
    }
}
