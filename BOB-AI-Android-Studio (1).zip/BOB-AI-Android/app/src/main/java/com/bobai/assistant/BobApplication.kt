package com.bobai.assistant

import android.app.Application
import com.bobai.assistant.data.local.BobDatabase
import com.bobai.assistant.data.local.MemoryEngine
import com.bobai.assistant.domain.agent.ActionExecutor
import com.bobai.assistant.domain.agent.AiBrain
import com.bobai.assistant.domain.agent.BobAgentOrchestrator
import com.bobai.assistant.domain.agent.ContextManager
import com.bobai.assistant.domain.agent.SecurityManager
import com.bobai.assistant.domain.brain.SecureKeyStore
import com.bobai.assistant.domain.brain.UniversalAiRouter
import com.bobai.assistant.domain.vision.VisionCostGuard
import com.bobai.assistant.domain.vision.VisualAgentEngine
import com.bobai.assistant.domain.vision.VisualModelRouter
import com.bobai.assistant.system.ToolSystem
import com.bobai.assistant.system.vision.OcrEngine
import com.bobai.assistant.system.vision.ScreenCaptureManager
import com.bobai.assistant.voice.SpeechEngine
import com.bobai.assistant.voice.VoiceEngine

class AppContainer(application: Application) {
    val database = BobDatabase.getInstance(application)
    val dao = database.dao()
    val memoryEngine = MemoryEngine(dao)
    val keyStore = SecureKeyStore(application)
    val aiRouter = UniversalAiRouter(application, keyStore)
    val visionCostGuard = VisionCostGuard(application)
    val visualRouter = VisualModelRouter(aiRouter, visionCostGuard)
    val captureManager = ScreenCaptureManager(application)
    val ocrEngine = OcrEngine()
    val visualAgent = VisualAgentEngine(
        captureManager = captureManager,
        ocrEngine = ocrEngine,
        visualRouter = visualRouter,
        dao = dao
    )
    val toolSystem = ToolSystem(application, captureManager)
    val speechEngine = SpeechEngine(application)
    val voiceEngine = VoiceEngine(application)
    val securityManager = SecurityManager()
    val contextManager = ContextManager()
    val aiBrain = AiBrain(aiRouter)
    val actionExecutor = ActionExecutor(
        tools = toolSystem,
        memoryEngine = memoryEngine,
        visualAgent = visualAgent,
        security = securityManager,
        dao = dao
    )
    val orchestrator = BobAgentOrchestrator(
        aiBrain = aiBrain,
        executor = actionExecutor,
        memoryEngine = memoryEngine,
        contextManager = contextManager,
        securityManager = securityManager,
        toolSystem = toolSystem,
        visualAgent = visualAgent,
        dao = dao
    )
}

class BobApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
