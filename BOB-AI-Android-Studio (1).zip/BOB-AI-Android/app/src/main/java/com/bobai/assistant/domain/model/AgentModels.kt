package com.bobai.assistant.domain.model

import kotlinx.serialization.Serializable

enum class AvatarState {
    IDLE,
    LISTENING,
    PROCESSING,
    ANALYZING_SCREEN,
    SPEAKING,
    EXECUTING,
    ERROR
}

enum class RiskLevel {
    SAFE,
    ELEVATED,
    CRITICAL
}

enum class StepStatus {
    PENDING,
    RUNNING,
    COMPLETED,
    FAILED,
    AWAITING_CONFIRMATION,
    CANCELLED
}

enum class ModelRole {
    DIALOG,
    DOCUMENT_ANALYSIS,
    COMPLEX_PLANNING,
    VISION_AGENT
}

@Serializable
data class PlannedStep(
    val id: String,
    val tool: String,
    val params: Map<String, String> = emptyMap(),
    val humanLabel: String,
    val rationale: String = "",
    val riskLevel: String = "SAFE",
    val requiresConfirmation: Boolean = false,
    val confirmationPrompt: String? = null,
    val status: String = "PENDING",
    val attempts: Int = 0,
    val maxRetries: Int = 2,
    val resultMessage: String? = null
)

@Serializable
data class AgentPlanResponse(
    val heard: String,
    val understood: String,
    val reply: String,
    val steps: List<PlannedStep> = emptyList(),
    val memoryUpdates: List<MemoryDraft> = emptyList(),
    val sources: List<String> = emptyList()
)

@Serializable
data class MemoryDraft(
    val category: String,
    val key: String,
    val content: String,
    val importance: Int = 2
)

data class ToolResult(
    val success: Boolean,
    val verified: Boolean,
    val message: String,
    val data: String? = null
)

@Serializable
data class AiProviderConfig(
    val id: String,
    val displayName: String,
    val providerType: String, // "gemini", "openai_compat", "ollama_local"
    val baseUrl: String,
    val modelName: String,
    val temperature: Float = 0.4f,
    val enabled: Boolean = true,
    val supportsVision: Boolean = true,
    val maxImageEdgePx: Int = 1024,
    val dailyVisionLimit: Int = 120
)

@Serializable
data class VisualCoordinates(
    val x: Int = 0,
    val y: Int = 0,
    val endX: Int? = null,
    val endY: Int? = null,
    val space: String = "normalized_1000" // "normalized_1000" | "image_px" | "screen_px"
)

@Serializable
data class VisualElementInfo(
    val label: String = "",
    val role: String = "button", // button | input | text | menu | toggle | icon | link
    val x: Int = 0,
    val y: Int = 0,
    val width: Int = 0,
    val height: Int = 0,
    val interactive: Boolean = true
)

@Serializable
data class VisualDecision(
    val screenDescription: String = "",
    val elements: List<VisualElementInfo> = emptyList(),
    val action: String = "done", // tap | double_tap | long_press | swipe | scroll | input_text | back | wait | done | abort
    val coordinates: VisualCoordinates? = null,
    val targetText: String = "",
    val inputText: String = "",
    val scrollDirection: String = "down", // down | up | left | right
    val confidence: Float = 0.0f,
    val reason: String = "",
    val goalAchieved: Boolean = false,
    val screenProtected: Boolean = false
)

data class VisualStepTrace(
    val stepIndex: Int,
    val phase: String,
    val action: String,
    val reason: String,
    val confidence: Float,
    val screenX: Int?,
    val screenY: Int?,
    val verified: Boolean,
    val message: String
)

data class OnboardingPermissionStatus(
    val id: String,
    val title: String,
    val rationale: String,
    val granted: Boolean,
    val requiredForCore: Boolean,
    val oemHint: String? = null
)

data class PipelineStatus(
    val heard: String = "",
    val understood: String = "",
    val currentlyExecuting: String = "",
    val completedSteps: List<String> = emptyList(),
    val pendingPermissions: List<String> = emptyList(),
    val awaitingConfirmation: PlannedStep? = null,
    val isAnalyzingScreen: Boolean = false,
    val visualPhase: String = "",
    val visualGoal: String = "",
    val visualStepCount: Int = 0,
    val visualMaxSteps: Int = 12,
    val lastVisualDecision: VisualDecision? = null,
    val visualTraces: List<VisualStepTrace> = emptyList(),
    val lastModelUsed: String = "",
    val errorBanner: String? = null
)
