package com.bobai.assistant.system.vision

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Base64
import android.util.DisplayMetrics
import android.view.WindowManager
import com.bobai.assistant.service.BobScreenCaptureService
import com.bobai.assistant.system.accessibility.BobAccessibilityService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.roundToInt

data class ScreenMetricsInfo(
    val widthPx: Int,
    val heightPx: Int,
    val densityDpi: Int,
    val isLandscape: Boolean
)

data class CapturedScreenFrame(
    val bitmap: Bitmap,
    val base64Jpeg: String,
    val mimeType: String,
    val imageWidth: Int,
    val imageHeight: Int,
    val screenWidth: Int,
    val screenHeight: Int,
    val isLandscape: Boolean,
    val capturedAtMs: Long,
    val isProtectedFlagSecure: Boolean,
    val perceptualHash: Long,
    val source: String // "media_projection" | "accessibility_screenshot"
)

class ScreenCaptureManager(private val context: Context) {

    private val projectionManager =
        context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var configuredWidth = 0
    private var configuredHeight = 0
    private var configuredDpi = 0

    private val captureThread = HandlerThread("bob-screen-capture").apply { start() }
    private val captureHandler = Handler(captureThread.looper)

    private val _hasMediaProjectionConsent = MutableStateFlow(false)
    val hasMediaProjectionConsent: StateFlow<Boolean> = _hasMediaProjectionConsent

    private val _previewEnabled = MutableStateFlow(true)
    val previewEnabled: StateFlow<Boolean> = _previewEnabled

    private val _lastPreviewBitmap = MutableStateFlow<Bitmap?>(null)
    val lastPreviewBitmap: StateFlow<Bitmap?> = _lastPreviewBitmap

    fun setPreviewEnabled(enabled: Boolean) {
        _previewEnabled.value = enabled
        if (!enabled) {
            _lastPreviewBitmap.value = null
        }
    }

    fun createConsentIntent(): Intent = projectionManager.createScreenCaptureIntent()

    fun currentScreenMetrics(): ScreenMetricsInfo {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val isLandscape =
            context.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = wm.currentWindowMetrics.bounds
            val dpi = context.resources.displayMetrics.densityDpi
            ScreenMetricsInfo(
                widthPx = bounds.width().coerceAtLeast(100),
                heightPx = bounds.height().coerceAtLeast(100),
                densityDpi = dpi.coerceAtLeast(160),
                isLandscape = isLandscape
            )
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            ScreenMetricsInfo(
                widthPx = dm.widthPixels.coerceAtLeast(100),
                heightPx = dm.heightPixels.coerceAtLeast(100),
                densityDpi = dm.densityDpi.coerceAtLeast(160),
                isLandscape = isLandscape
            )
        }
    }

    suspend fun bindMediaProjectionConsent(resultCode: Int, data: Intent?): Boolean {
        if (resultCode != Activity.RESULT_OK || data == null) {
            _hasMediaProjectionConsent.value = false
            return false
        }

        val svcIntent = Intent(context, BobScreenCaptureService::class.java).apply {
            action = BobScreenCaptureService.ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(svcIntent)
        } else {
            context.startService(svcIntent)
        }

        // Wait until BobScreenCaptureService confirms foreground mediaProjection type is active
        val ready = withTimeoutOrNull(3500L) {
            BobScreenCaptureService.isForegroundReady.first { it }
        } ?: false
        if (!ready) return false

        releaseProjectionResources()
        val projection = projectionManager.getMediaProjection(resultCode, data) ?: return false
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                _hasMediaProjectionConsent.value = false
                releaseProjectionResources()
            }
        }, captureHandler)

        mediaProjection = projection
        _hasMediaProjectionConsent.value = true
        return true
    }

    fun releaseProjection() {
        _hasMediaProjectionConsent.value = false
        releaseProjectionResources()
        context.startService(
            Intent(context, BobScreenCaptureService::class.java).apply {
                action = BobScreenCaptureService.ACTION_STOP
            }
        )
    }

    private fun releaseProjectionResources() {
        runCatching { virtualDisplay?.release() }
        virtualDisplay = null
        runCatching { imageReader?.close() }
        imageReader = null
        runCatching { mediaProjection?.stop() }
        mediaProjection = null
        configuredWidth = 0
        configuredHeight = 0
        configuredDpi = 0
    }

    suspend fun captureFreshScreen(
        maxEdgePx: Int = 1024,
        jpegQuality: Int = 80,
        maxAgeMs: Long = 1500L
    ): CapturedScreenFrame? = withContext(Dispatchers.Default) {
        val metrics = currentScreenMetrics()
        val captureStartedAt = System.currentTimeMillis()

        var rawBitmap: Bitmap? = null
        var source = "media_projection"

        if (mediaProjection != null && _hasMediaProjectionConsent.value) {
            rawBitmap = captureViaMediaProjection(metrics)
        }

        if (rawBitmap == null) {
            val acc = BobAccessibilityService.instance
            if (acc != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                rawBitmap = acc.takeAccessibilityScreenshot()
                source = "accessibility_screenshot"
            }
        }

        val capturedBitmap = rawBitmap ?: return@withContext null
        val elapsed = System.currentTimeMillis() - captureStartedAt
        if (elapsed > maxAgeMs * 4) {
            // Still valid, though we update timestamp accurately
        }

        val isProtected = isFrameLikelyProtected(capturedBitmap)
        val scaled = scaleBitmapPreservingAspect(capturedBitmap, maxEdgePx.coerceIn(512, 1600))
        if (scaled !== capturedBitmap) {
            capturedBitmap.recycle()
        }

        val baos = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, jpegQuality.coerceIn(50, 92), baos)
        val jpegBytes = baos.toByteArray()
        val base64 = Base64.encodeToString(jpegBytes, Base64.NO_WRAP)
        val pHash = computePerceptualHash(scaled)

        if (_previewEnabled.value) {
            _lastPreviewBitmap.value = scaled.copy(Bitmap.Config.ARGB_8888, false)
        }

        CapturedScreenFrame(
            bitmap = scaled,
            base64Jpeg = base64,
            mimeType = "image/jpeg",
            imageWidth = scaled.width,
            imageHeight = scaled.height,
            screenWidth = metrics.widthPx,
            screenHeight = metrics.heightPx,
            isLandscape = metrics.isLandscape,
            capturedAtMs = System.currentTimeMillis(),
            isProtectedFlagSecure = isProtected,
            perceptualHash = pHash,
            source = source
        )
    }

    private suspend fun captureViaMediaProjection(metrics: ScreenMetricsInfo): Bitmap? {
        val proj = mediaProjection ?: return null
        ensureVirtualDisplay(proj, metrics)
        val reader = imageReader ?: return null

        // Drain stale buffered frames first so the captured frame is guaranteed fresh
        runCatching {
            while (true) {
                val stale = reader.acquireLatestImage() ?: break
                stale.close()
            }
        }

        return withTimeoutOrNull(2200L) {
            suspendCancellableCoroutine { cont ->
                var completed = false
                reader.setOnImageAvailableListener({ r ->
                    if (completed) return@setOnImageAvailableListener
                    var image: Image? = null
                    try {
                        image = r.acquireLatestImage()
                        if (image != null) {
                            completed = true
                            r.setOnImageAvailableListener(null, null)
                            val bmp = imageToBitmap(image)
                            if (cont.isActive) cont.resume(bmp)
                        }
                    } catch (_: Throwable) {
                        if (!completed && cont.isActive) {
                            completed = true
                            cont.resume(null)
                        }
                    } finally {
                        image?.close()
                    }
                }, captureHandler)
            }
        }
    }

    private fun ensureVirtualDisplay(proj: MediaProjection, metrics: ScreenMetricsInfo) {
        if (
            virtualDisplay != null &&
            configuredWidth == metrics.widthPx &&
            configuredHeight == metrics.heightPx &&
            configuredDpi == metrics.densityDpi
        ) {
            return
        }

        runCatching { virtualDisplay?.release() }
        runCatching { imageReader?.close() }

        configuredWidth = metrics.widthPx
        configuredHeight = metrics.heightPx
        configuredDpi = metrics.densityDpi

        imageReader = ImageReader.newInstance(
            configuredWidth,
            configuredHeight,
            PixelFormat.RGBA_8888,
            2
        )
        virtualDisplay = proj.createVirtualDisplay(
            "BobAiVisualDisplay",
            configuredWidth,
            configuredHeight,
            configuredDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface,
            null,
            captureHandler
        )
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width

        val fullBitmap = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        fullBitmap.copyPixelsFromBuffer(buffer)
        if (rowPadding == 0) return fullBitmap

        val cropped = Bitmap.createBitmap(fullBitmap, 0, 0, image.width, image.height)
        fullBitmap.recycle()
        return cropped
    }

    private fun scaleBitmapPreservingAspect(src: Bitmap, maxEdge: Int): Bitmap {
        val largest = max(src.width, src.height)
        if (largest <= maxEdge) return src
        val ratio = maxEdge.toFloat() / largest.toFloat()
        val w = (src.width * ratio).roundToInt().coerceAtLeast(1)
        val h = (src.height * ratio).roundToInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(src, w, h, true)
    }

    private fun isFrameLikelyProtected(bitmap: Bitmap): Boolean {
        val stepX = (bitmap.width / 8).coerceAtLeast(1)
        val stepY = (bitmap.height / 8).coerceAtLeast(1)
        var nonBlackPixels = 0
        for (y in stepY until bitmap.height step stepY) {
            for (x in stepX until bitmap.width step stepX) {
                val pixel = bitmap.getPixel(x, y)
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                if (r > 12 || g > 12 || b > 12) {
                    nonBlackPixels++
                }
            }
        }
        return nonBlackPixels == 0
    }

    private fun computePerceptualHash(bitmap: Bitmap): Long {
        val tiny = Bitmap.createScaledBitmap(bitmap, 8, 8, true)
        var sum = 0L
        val grays = IntArray(64)
        for (y in 0 until 8) {
            for (x in 0 until 8) {
                val p = tiny.getPixel(x, y)
                val gray = (((p shr 16) and 0xFF) * 30 + ((p shr 8) and 0xFF) * 59 + (p and 0xFF) * 11) / 100
                grays[y * 8 + x] = gray
                sum += gray
            }
        }
        tiny.recycle()
        val avg = sum / 64
        var hash = 0L
        for (i in 0 until 64) {
            if (grays[i] >= avg) hash = hash or (1L shl i)
        }
        return hash
    }
}
