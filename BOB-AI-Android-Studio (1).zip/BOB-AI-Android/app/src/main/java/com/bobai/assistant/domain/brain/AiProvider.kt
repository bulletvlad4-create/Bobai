package com.bobai.assistant.domain.brain

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.bobai.assistant.domain.model.AiProviderConfig
import com.bobai.assistant.domain.model.ModelRole
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.header
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.contentType
import io.ktor.http.isSuccess
import io.ktor.serialization.kotlinx.json.json
import kotlinx.coroutines.delay
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

interface AiProvider {
    val config: AiProviderConfig
    suspend fun complete(systemPrompt: String, userPrompt: String, apiKey: String?): String
}

object JsonExtractionUtils {
    fun extractJsonObject(raw: String): String {
        val trimmed = raw.trim()
        val fenceRegex = Regex("```(?:json)?\\s*([\\s\\S]*?)```", RegexOption.IGNORE_CASE)
        val fenced = fenceRegex.find(trimmed)?.groupValues?.getOrNull(1)?.trim()
        val candidate = fenced ?: trimmed
        val firstBrace = candidate.indexOf('{')
        val lastBrace = candidate.lastIndexOf('}')
        if (firstBrace >= 0 && lastBrace > firstBrace) {
            return candidate.substring(firstBrace, lastBrace + 1)
        }
        return candidate
    }
}

class SecureKeyStore(context: Context) {
    private val prefs: SharedPreferences = runCatching {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "bob_ai_secure_keys",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }.getOrElse {
        context.getSharedPreferences("bob_ai_secure_keys_fallback", Context.MODE_PRIVATE)
    }

    fun saveApiKey(providerId: String, apiKey: String) {
        prefs.edit().putString("key_$providerId", apiKey.trim()).apply()
    }

    fun getApiKey(providerId: String): String =
        prefs.getString("key_$providerId", "") ?: ""

    fun hasApiKey(providerId: String): Boolean = getApiKey(providerId).isNotBlank()
}

suspend fun executeHttpWithRetry(
    maxAttempts: Int = 3,
    initialDelayMs: Long = 600L,
    block: suspend () -> HttpResponse
): Pair<HttpResponse, String> {
    var lastError: Throwable? = null
    var delayMs = initialDelayMs
    for (attempt in 1..maxAttempts) {
        try {
            val response = block()
            val body = response.bodyAsText()
            if (response.status.isSuccess()) {
                return response to body
            }
            val code = response.status.value
            val retryable = code == 429 || code in 500..599
            val err = IllegalStateException("HTTP $code: ${body.take(280)}")
            if (!retryable || attempt == maxAttempts) {
                throw err
            }
            lastError = err
        } catch (t: Throwable) {
            lastError = t
            if (attempt == maxAttempts) throw t
        }
        delay(delayMs)
        delayMs *= 2
    }
    throw lastError ?: IllegalStateException("Неизвестная ошибка сети")
}

class GeminiAiProvider(
    override val config: AiProviderConfig,
    private val client: HttpClient
) : AiProvider {
    override suspend fun complete(systemPrompt: String, userPrompt: String, apiKey: String?): String {
        val key = apiKey?.takeIf { it.isNotBlank() }
            ?: error("API-ключ для Gemini не задан в настройках моделей.")

        val url = "${config.baseUrl.trimEnd('/')}/models/${config.modelName}:generateContent?key=$key"
        val payload = buildJsonObject {
            put("systemInstruction", buildJsonObject {
                put("parts", buildJsonArray {
                    add(buildJsonObject { put("text", systemPrompt) })
                })
            })
            put("contents", buildJsonArray {
                add(buildJsonObject {
                    put("role", "user")
                    put("parts", buildJsonArray {
                        add(buildJsonObject { put("text", userPrompt) })
                    })
                })
            })
            put("generationConfig", buildJsonObject {
                put("responseMimeType", "application/json")
            })
        }

        val (_, responseText) = executeHttpWithRetry {
            client.post(url) {
                contentType(ContentType.Application.Json)
                setBody(payload.toString())
            }
        }

        val root = Json.parseToJsonElement(responseText).jsonObject
        val candidates = root["candidates"]?.jsonArray
            ?: error("Gemini вернул пустой ответ: ${responseText.take(200)}")
        return candidates[0].jsonObject["content"]?.jsonObject?.get("parts")?.jsonArray
            ?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content
            ?: error("Gemini не вернул текстовую часть ответа.")
    }
}

class OpenAiCompatibleProvider(
    override val config: AiProviderConfig,
    private val client: HttpClient
) : AiProvider {
    override suspend fun complete(systemPrompt: String, userPrompt: String, apiKey: String?): String {
        val key = apiKey?.takeIf { it.isNotBlank() }
            ?: error("API-ключ для ${config.displayName} не задан.")

        val payload = buildJsonObject {
            put("model", config.modelName)
            put("temperature", config.temperature.toDouble())
            put("response_format", buildJsonObject { put("type", "json_object") })
            put("messages", buildJsonArray {
                add(buildJsonObject {
                    put("role", "system")
                    put("content", systemPrompt)
                })
                add(buildJsonObject {
                    put("role", "user")
                    put("content", userPrompt)
                })
            })
        }

        val (_, responseText) = executeHttpWithRetry {
            client.post("${config.baseUrl.trimEnd('/')}/chat/completions") {
                contentType(ContentType.Application.Json)
                header("Authorization", "Bearer $key")
                setBody(payload.toString())
            }
        }

        val root = Json.parseToJsonElement(responseText).jsonObject
        val choices = root["choices"] as? JsonArray ?: error("Некорректный ответ провайдера.")
        return choices[0].jsonObject["message"]?.jsonObject?.get("content")?.jsonPrimitive?.content
            ?: error("Провайдер вернул пустое сообщение.")
    }
}

class LocalOllamaProvider(
    override val config: AiProviderConfig,
    private val client: HttpClient
) : AiProvider {
    override suspend fun complete(systemPrompt: String, userPrompt: String, apiKey: String?): String {
        val payload = buildJsonObject {
            put("model", config.modelName)
            put("stream", false)
            put("format", "json")
            put("messages", buildJsonArray {
                add(buildJsonObject {
                    put("role", "system")
                    put("content", systemPrompt)
                })
                add(buildJsonObject {
                    put("role", "user")
                    put("content", userPrompt)
                })
            })
        }

        val (_, responseText) = executeHttpWithRetry(maxAttempts = 2) {
            client.post(config.baseUrl) {
                contentType(ContentType.Application.Json)
                setBody(payload.toString())
            }
        }

        val root = Json.parseToJsonElement(responseText).jsonObject
        return root["message"]?.jsonObject?.get("content")?.jsonPrimitive?.content
            ?: root["response"]?.jsonPrimitive?.content
            ?: error("Пустой ответ локальной модели Ollama.")
    }
}

class UniversalAiRouter(
    private val context: Context,
    val keyStore: SecureKeyStore
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("bob_ai_router_config", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    val httpClient: HttpClient = HttpClient(OkHttp) {
        install(HttpTimeout) {
            requestTimeoutMillis = 25_000
            connectTimeoutMillis = 10_000
            socketTimeoutMillis = 25_000
        }
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
    }

    private val defaultProviders = listOf(
        AiProviderConfig(
            id = "gemini-primary",
            displayName = "Google Gemini 2.5 Flash (Текст + Зрение)",
            providerType = "gemini",
            baseUrl = "https://generativelanguage.googleapis.com/v1beta",
            modelName = "gemini-2.5-flash",
            enabled = true,
            supportsVision = true,
            maxImageEdgePx = 1024,
            dailyVisionLimit = 150
        ),
        AiProviderConfig(
            id = "openai-compat",
            displayName = "OpenAI Vision API (GPT-4o-mini / GPT-4o)",
            providerType = "openai_compat",
            baseUrl = "https://api.openai.com/v1",
            modelName = "gpt-4o-mini",
            enabled = false,
            supportsVision = true,
            maxImageEdgePx = 1024,
            dailyVisionLimit = 100
        ),
        AiProviderConfig(
            id = "ollama-local",
            displayName = "Локальная модель (Ollama / llama.cpp)",
            providerType = "ollama_local",
            baseUrl = "http://127.0.0.1:11434/api/chat",
            modelName = "qwen2.5vl:7b",
            enabled = false,
            supportsVision = true,
            maxImageEdgePx = 896,
            dailyVisionLimit = 500
        )
    )

    private val providers = mutableListOf<AiProviderConfig>().apply {
        val saved = prefs.getString("providers_json", null)
        val parsed = saved?.let { runCatching { json.decodeFromString<List<AiProviderConfig>>(it) }.getOrNull() }
        if (!parsed.isNullOrEmpty()) addAll(parsed) else addAll(defaultProviders)
    }

    private val roleBindings = mutableMapOf(
        ModelRole.DIALOG to (prefs.getString("role_DIALOG", "gemini-primary") ?: "gemini-primary"),
        ModelRole.DOCUMENT_ANALYSIS to (prefs.getString("role_DOCUMENT_ANALYSIS", "gemini-primary") ?: "gemini-primary"),
        ModelRole.COMPLEX_PLANNING to (prefs.getString("role_COMPLEX_PLANNING", "gemini-primary") ?: "gemini-primary"),
        ModelRole.VISION_AGENT to (prefs.getString("role_VISION_AGENT", "gemini-primary") ?: "gemini-primary")
    )

    fun listProviders(): List<AiProviderConfig> = synchronized(providers) { providers.toList() }

    fun getRoleBinding(role: ModelRole): String = roleBindings[role] ?: "gemini-primary"

    fun bindRole(role: ModelRole, providerId: String) {
        roleBindings[role] = providerId
        prefs.edit().putString("role_${role.name}", providerId).apply()
    }

    fun updateProvider(updated: AiProviderConfig, newApiKey: String? = null) {
        synchronized(providers) {
            val idx = providers.indexOfFirst { it.id == updated.id }
            if (idx >= 0) providers[idx] = updated else providers.add(updated)
            prefs.edit().putString("providers_json", json.encodeToString(providers)).apply()
        }
        if (!newApiKey.isNullOrBlank()) {
            keyStore.saveApiKey(updated.id, newApiKey)
        }
    }

    fun orderedProvidersForRole(role: ModelRole, requireVision: Boolean = false): List<AiProviderConfig> {
        val snapshot = listProviders().filter { !requireVision || it.supportsVision }
        val preferredId = roleBindings[role]
        val preferred = snapshot.find { it.id == preferredId && it.enabled }
            ?: snapshot.find { it.id == preferredId }
        val others = snapshot.filter { it.id != preferred?.id && it.enabled }
        return listOfNotNull(preferred) + others
    }

    suspend fun executeWithFallback(
        role: ModelRole,
        systemPrompt: String,
        userPrompt: String
    ): Pair<String, String> {
        val ordered = orderedProvidersForRole(role, requireVision = false)
        var lastError: Throwable? = null
        for (cfg in ordered) {
            try {
                val impl: AiProvider = when (cfg.providerType) {
                    "gemini" -> GeminiAiProvider(cfg, httpClient)
                    "ollama_local" -> LocalOllamaProvider(cfg, httpClient)
                    else -> OpenAiCompatibleProvider(cfg, httpClient)
                }
                val result = impl.complete(systemPrompt, userPrompt, keyStore.getApiKey(cfg.id))
                return JsonExtractionUtils.extractJsonObject(result) to cfg.modelName
            } catch (t: Throwable) {
                lastError = t
            }
        }
        throw IllegalStateException(
            "Все настроенные AI-провайдеры недоступны: ${lastError?.message ?: "добавьте API-ключ в разделе Система"}"
        )
    }
}
