package com.bobai.assistant.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.bobai.assistant.domain.model.AvatarState
import kotlin.math.cos
import kotlin.math.sin

val BobColors = darkColorScheme(
    primary = Color(0xFF38BDF8),
    onPrimary = Color(0xFF090C12),
    secondary = Color(0xFFA855F7),
    background = Color(0xFF090C12),
    surface = Color(0xFF111622),
    surfaceVariant = Color(0xFF161D2C),
    onBackground = Color(0xFFF1F5F9),
    onSurface = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF94A3B8),
    error = Color(0xFFEF4444)
)

@Composable
fun BobTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = BobColors,
        content = content
    )
}

@Composable
fun BobAvatarOrb(
    state: AvatarState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "bob_orb")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    AvatarState.ANALYZING_SCREEN -> 1000
                    AvatarState.PROCESSING -> 1400
                    else -> 3400
                },
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    val accent = when (state) {
        AvatarState.IDLE -> Color(0xFF38BDF8)
        AvatarState.LISTENING -> Color(0xFF22D3EE)
        AvatarState.PROCESSING -> Color(0xFF818CF8)
        AvatarState.ANALYZING_SCREEN -> Color(0xFFA855F7)
        AvatarState.SPEAKING -> Color(0xFF10B981)
        AvatarState.EXECUTING -> Color(0xFFF59E0B)
        AvatarState.ERROR -> Color(0xFFEF4444)
    }

    Canvas(
        modifier = modifier
            .size(164.dp)
            .clickable(onClick = onClick)
    ) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val baseRadius = size.minDimension * 0.34f

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(accent.copy(alpha = 0.28f), Color.Transparent),
                center = center,
                radius = size.minDimension * 0.5f
            ),
            radius = size.minDimension * 0.5f,
            center = center
        )

        drawCircle(
            color = accent.copy(alpha = 0.78f),
            radius = baseRadius,
            center = center,
            style = Stroke(width = 3.dp.toPx())
        )

        if (state == AvatarState.ANALYZING_SCREEN) {
            drawCircle(
                color = Color(0xFF38BDF8).copy(alpha = 0.45f),
                radius = baseRadius * 1.4f,
                center = center,
                style = Stroke(width = 1.5.dp.toPx())
            )
        }

        val orbitRadius = baseRadius * 1.24f
        val dotCount = if (state == AvatarState.ANALYZING_SCREEN) 8 else 6
        for (i in 0 until dotCount) {
            val angle = Math.toRadians((phase + i * (360f / dotCount)).toDouble())
            val dotPos = Offset(
                x = center.x + (orbitRadius * cos(angle)).toFloat(),
                y = center.y + (orbitRadius * sin(angle)).toFloat()
            )
            drawCircle(color = accent, radius = 3.dp.toPx(), center = dotPos)
        }
    }
}
