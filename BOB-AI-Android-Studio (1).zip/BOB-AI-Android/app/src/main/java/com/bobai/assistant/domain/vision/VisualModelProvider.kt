package com.bobai.assistant.domain.vision

import android.content.Context
import android.content.SharedPreferences
import com.bobai.assistant.domain.brain.JsonExtractionUtils
import com.bobai.assistant.domain.brain.UniversalAiRouter
import com.bobai.assistant.domain.brain.executeHttpWithRetry
import com.bobai.assistant.domain.model.AiProviderConfig
import com.bobai.assistant.domain.model.ModelRole
import com.bobai.assistant.domain.model.VisualCoordinates
import com.bobai.assistant.domain.model.VisualDecision
import io.ktor.client.HttpClient
import io.ktor.client.request.header
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.contentType
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import java.time.LocalDate

interface VisualModelProvider {
    val config: AiProviderConfig
    val supportsVision: Boolean
        get() = config.supportsVision

    suspend fun analyzeScreen(
        imageBase64: String,
        mimeType: String,
        imageWidth: Int,
        imageHeight: Int,
        screenWidth: Int,
        screenHeight: Int,
        userGoal: String,
        accessibilitySummary: String,
        ocrSummary: String,
        stepHistory: List<String>,
        apiKey: String?
    ): VisualDecision
}

object VisualDecisionValidator {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private val allowedActions = setOf(
        "tap", "double_tap", "long_press", "swipe", "scroll",
        "input_text", "back", "wait", "done", "abort"
    )

    fun parseAndValidate(rawJson: String): VisualDecision {
        val cleaned = JsonExtractionUtils.extractJsonObject(rawJson)
        val parsed = json.decodeFromString<VisualDecision>(cleaned)
        val normalizedAction = parsed.action.trim().lowercase()
        require(normalizedAction in allowedActions) {
            "Недопустимое визуальное действие модели: ${parsed.action}"
        }
        val clampedConfidence = parsed.confidence.coerceIn(0f, 1f)
        return parsed.copy(
            action = normalizedAction,
            confidence = clampedConfidence
        )
    }

    /**
     * Converts coordinates from normalized 0..1000 space, resized image pixels, or screen pixels
     * into clamped physical screen coordinates suitable for AccessibilityService.dispatchGesture.
     */
    fun toScreenPixels(
        coords: VisualCoordinates?,
        imageWidth: Int,
        imageHeight: Int,
        screenWidth: Int,
        screenHeight: Int
    ): Pair<Int, Int>? {
        coords ?: return null
        val safeScreenW = screenWidth.coerceAtLeast(1)
        val safeScreenH = screenHeight.coerceAtLeast(1)
        val safeImgW = imageWidth.coerceAtLeast(1)
        val safeImgH = imageHeight.coerceAtLeast(1)

        val (px, py) = when (coords.space.lowercase()) {
            "screen_px" -> coords.x to coords.y
            "image_px" -> {
                val sx = (coords.x.toFloat() / safeImgW * safeScreenW).toInt()
                val sy = (coords.y.toFloat() / safeImgH * safeScreenH).toInt()
                sx to sy
            }
            else -> {
                // Default: normalized 0..1000
                val sx = (coords.x.coerceIn(0, 1000) / 1000f * safeScreenW).toInt()
                val sy = (coords.y.coerceIn(0, 1000) / 1000f * safeScreenH).toInt()
                sx to sy
            }
        }
        return px.coerceIn(4, safeScreenW - 4) to py.coerceIn(4, safeScreenH - 4)
    }

    fun toScreenSwipePoints(
        coords: VisualCoordinates?,
        imageWidth: Int,
        imageHeight: Int,
        screenWidth: Int,
        screenHeight: Int
    ): Pair<Pair<Int, Int>, Pair<Int, Int>>? {
        val start = toScreenPixels(coords, imageWidth, imageHeight, screenWidth, screenHeight) ?: return null
        val ex = coords?.endX ?: return null
        val ey = coords.endY ?: return null
        val end = toScreenPixels(
            coords.copy(x = ex, y = ey),
            imageWidth,
            imageHeight,
            screenWidth,
            screenHeight
        ) ?: return null
        return start to end
    }
}

class VisionCostGuard(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("bob_ai_vision_budget", Context.MODE_PRIVATE)

    @Synchronized
    fun canMakeVisionCall(dailyLimit: Int): Boolean {
        val today = LocalDate.now().toString()
        val storedDay = prefs.getString("day", "")
        val count = if (storedDay == today) prefs.getInt("count", 0) else 0
        return count < dailyLimit.coerceAtLeast(1)
    }

    @Synchronized
    fun recordVisionCall(): Int {
        val today = LocalDate.now().toString()
        val storedDay = prefs.getString("day", "")
        val current = if (storedDay == today) prefs.getInt("count", 0) else 0
        val next = current + 1
        prefs.edit().putString("day", today).putInt("count", next).apply()
        return next
    }

    @Synchronized
    fun getTodayCount(): Int {
        val today = LocalDate.now().toString()
        return if (prefs.getString("day", "") == today) prefs.getInt("count", 0) else 0
    }
}

internal fun buildVisualPrompt(
    userGoal: String,
    imageWidth: Int,
    imageHeight: Int,
    screenWidth: Int,
    screenHeight: Int,
    accessibilitySummary: String,
    ocrSummary: String,
    stepHistory: List<String>
): Pair<String, String> {
    val systemPrompt = """
        Ты — модуль Visual AI Agent внутри автономного Android-агента BOB AI.
        Ты анализируешь реальный скриншот экрана Android, дерево Accessibility и текст OCR.
        Твоя задача — определить текущее состояние интерфейса и выбрать ОДНО точное следующее действие для достижения цели пользователя.

        ПРАВИЛА:
        1. Никогда не выдумывай элементы, которых нет на изображении или в дереве UI.
        2. Если экран чёрный или видно сообщение о запрете захвата (FLAG_SECURE), установи "screenProtected": true и "action": "abort".
        3. Координаты передавай в нормализованном масштабе 0..1000 ("space": "normalized_1000"), где (0,0) — левый верхний угол изображения, а (1000,1000) — правый нижний угол.
        4. Если цель уже достигнута на текущем экране — верни "action": "done", "goalAchieved": true.
        5. Сочетай текстовый поиск ("targetText") и точные координаты центра элемента ("coordinates"), чтобы агент мог использовать AccessibilityService и dispatchGesture.
        6. Для ввода текста укажи координаты поля ввода И "inputText".
        7. Отвечай СТРОГО JSON-объектом схемы:
        {
          "screenDescription": "краткое описание экрана на русском",
          "elements": [{"label":"...", "role":"button|input|text|menu|toggle|icon", "x":500, "y":200, "width":200, "height":80, "interactive":true}],
          "action": "tap|double_tap|long_press|swipe|scroll|input_text|back|wait|done|abort",
          "coordinates": {"x":540, "y":820, "endX":null, "endY":null, "space":"normalized_1000"},
          "targetText": "текст кнопки или поля если есть",
          "inputText": "вводимый текст для input_text",
          "scrollDirection": "down|up|left|right",
          "confidence": 0.95,
          "reason": "понятное пояснение шага на русском",
          "goalAchieved": false,
          "screenProtected": false
        }
    """.trimIndent()

    val userPrompt = """
        ЦЕЛЬ ПОЛЬЗОВАТЕЛЯ: $userGoal
        РАЗМЕР ИЗОБРАЖЕНИЯ: ${imageWidth}x${imageHeight}, ЭКРАН УСТРОЙСТВА: ${screenWidth}x${screenHeight}

        УЖЕ ВЫПОЛНЕННЫЕ ВИЗУАЛЬНЫЕ ШАГИ:
        ${if (stepHistory.isEmpty()) "Первый шаг цикла" else stepHistory.joinToString("\n")}

        ACCESSIBILITY TREE (видимые узлы):
        ${accessibilitySummary.ifBlank { "Недоступно или пусто" }}

        OCR РАСПОЗНАННЫЙ ТЕКСТ:
        ${ocrSummary.ifBlank { "Не распознано" }}
    """.trimIndent()

    return systemPrompt to userPrompt
}

class GeminiVisualProvider(
    override val config: AiProviderConfig,
    private val client: HttpClient
) : VisualModelProvider {
    override suspend fun analyzeScreen(
        imageBase64: String,
        mimeType: String,
        imageWidth: Int,
        imageHeight: Int,
        screenWidth: Int,
        screenHeight: Int,
        userGoal: String,
        accessibilitySummary: String,
        ocrSummary: String,
        stepHistory: List<String>,
        apiKey: String?
    ): VisualDecision {
        require(config.supportsVision) {
            "Модель ${config.modelName} помечена как текстовая и не поддерживает анализ изображений."
        }
        val key = apiKey?.takeIf { it.isNotBlank() }
            ?: error("API-ключ для мультимодальной модели Gemini не задан.")

        val (sysPrompt, usrPrompt) = buildVisualPrompt(
            userGoal, imageWidth, imageHeight, screenWidth, screenHeight,
            accessibilitySummary, ocrSummary, stepHistory
        )
        val url = "${config.baseUrl.trimEnd('/')}/models/${config.modelName}:generateContent?key=$key"

        val payload = buildJsonObject {
            put("systemInstruction", buildJsonObject {
                put("parts", buildJsonArray {
                    add(buildJsonObject { put("text", sysPrompt) })
                })
            })
            put("contents", buildJsonArray {
                add(buildJsonObject {
                    put("role", "user")
                    put("parts", buildJsonArray {
                        add(buildJsonObject {
                            put("inline_data", buildJsonObject {
                                put("mime_type", mimeType)
                                put("data", imageBase64)
                            })
                        })
                        add(buildJsonObject { put("text", usrPrompt) })
                    })
                })
            })
            put("generationConfig", buildJsonObject {
                put("responseMimeType", "application/json")
            })
        }

        val (_, responseText) = executeHttpWithRetry {
            client.post(url) {
                contentType(ContentType.Application.Json)
                setBody(payload.toString())
            }
        }

        val root = Json.parseToJsonElement(responseText).jsonObject
        val text = root["candidates"]?.jsonArray?.firstOrNull()
            ?.jsonObject?.get("content")?.jsonObject?.get("parts")?.jsonArray?.firstOrNull()
            ?.jsonObject?.get("text")?.jsonPrimitive?.content
            ?: error("Gemini Vision вернул пустой ответ.")
        return VisualDecisionValidator.parseAndValidate(text)
    }
}

class OpenAiVisionProvider(
    override val config: AiProviderConfig,
    private val client: HttpClient
) : VisualModelProvider {
    override suspend fun analyzeScreen(
        imageBase64: String,
        mimeType: String,
        imageWidth: Int,
        imageHeight: Int,
        screenWidth: Int,
        screenHeight: Int,
        userGoal: String,
        accessibilitySummary: String,
        ocrSummary: String,
        stepHistory: List<String>,
        apiKey: String?
    ): VisualDecision {
        require(config.supportsVision) {
            "Модель ${config.modelName} не поддерживает изображения."
        }
        val key = apiKey?.takeIf { it.isNotBlank() }
            ?: error("API-ключ для ${config.displayName} не задан.")

        val (sysPrompt, usrPrompt) = buildVisualPrompt(
            userGoal, imageWidth, imageHeight, screenWidth, screenHeight,
            accessibilitySummary, ocrSummary, stepHistory
        )

        val payload = buildJsonObject {
            put("model", config.modelName)
            put("temperature", 0.2)
            put("response_format", buildJsonObject { put("type", "json_object") })
            put("messages", buildJsonArray {
                add(buildJsonObject {
                    put("role", "system")
                    put("content", sysPrompt)
                })
                add(buildJsonObject {
                    put("role", "user")
                    put("content", buildJsonArray {
                        add(buildJsonObject {
                            put("type", "text")
                            put("text", usrPrompt)
                        })
                        add(buildJsonObject {
                            put("type", "image_url")
                            put("image_url", buildJsonObject {
                                put("url", "data:$mimeType;base64,$imageBase64")
                                put("detail", "high")
                            })
                        })
                    })
                })
            })
        }

        val (_, responseText) = executeHttpWithRetry {
            client.post("${config.baseUrl.trimEnd('/')}/chat/completions") {
                contentType(ContentType.Application.Json)
                header("Authorization", "Bearer $key")
                setBody(payload.toString())
            }
        }

        val root = Json.parseToJsonElement(responseText).jsonObject
        val choices = root["choices"] as? JsonArray ?: error("Некорректный ответ Vision API.")
        val content = choices[0].jsonObject["message"]?.jsonObject?.get("content")?.jsonPrimitive?.content
            ?: error("Пустой ответ OpenAI Vision.")
        return VisualDecisionValidator.parseAndValidate(content)
    }
}

class OllamaVisionProvider(
    override val config: AiProviderConfig,
    private val client: HttpClient
) : VisualModelProvider {
    override suspend fun analyzeScreen(
        imageBase64: String,
        mimeType: String,
        imageWidth: Int,
        imageHeight: Int,
        screenWidth: Int,
        screenHeight: Int,
        userGoal: String,
        accessibilitySummary: String,
        ocrSummary: String,
        stepHistory: List<String>,
        apiKey: String?
    ): VisualDecision {
        require(config.supportsVision) {
            "Локальная модель ${config.modelName} помечена как текстовая. Выберите VLM (например qwen2.5vl или llava)."
        }

        val (sysPrompt, usrPrompt) = buildVisualPrompt(
            userGoal, imageWidth, imageHeight, screenWidth, screenHeight,
            accessibilitySummary, ocrSummary, stepHistory
        )

        val payload = buildJsonObject {
            put("model", config.modelName)
            put("stream", false)
            put("format", "json")
            put("messages", buildJsonArray {
                add(buildJsonObject {
                    put("role", "system")
                    put("content", sysPrompt)
                })
                add(buildJsonObject {
                    put("role", "user")
                    put("content", usrPrompt)
                    put("images", buildJsonArray {
                        add(kotlinx.serialization.json.JsonPrimitive(imageBase64))
                    })
                })
            })
        }

        val (_, responseText) = executeHttpWithRetry(maxAttempts = 2) {
            client.post(config.baseUrl) {
                contentType(ContentType.Application.Json)
                setBody(payload.toString())
            }
        }

        val root = Json.parseToJsonElement(responseText).jsonObject
        val text = root["message"]?.jsonObject?.get("content")?.jsonPrimitive?.content
            ?: root["response"]?.jsonPrimitive?.content
            ?: error("Пустой ответ локальной VLM модели.")
        return VisualDecisionValidator.parseAndValidate(text)
    }
}

class VisualModelRouter(
    private val aiRouter: UniversalAiRouter,
    val costGuard: VisionCostGuard
) {
    suspend fun analyzeWithFallback(
        imageBase64: String,
        mimeType: String,
        imageWidth: Int,
        imageHeight: Int,
        screenWidth: Int,
        screenHeight: Int,
        userGoal: String,
        accessibilitySummary: String,
        ocrSummary: String,
        stepHistory: List<String>
    ): Pair<VisualDecision, String> {
        val candidates = aiRouter.orderedProvidersForRole(ModelRole.VISION_AGENT, requireVision = true)
        if (candidates.isEmpty()) {
            throw IllegalStateException("Нет активной мультимодальной модели с поддержкой зрения (supportsVision=true).")
        }

        val maxDaily = candidates.first().dailyVisionLimit
        if (!costGuard.canMakeVisionCall(maxDaily)) {
            throw IllegalStateException("Достигнут суточный лимит вызовов Vision AI ($maxDaily) для контроля расходов.")
        }

        val maxPayloadChars = 2_400_000
        if (imageBase64.length > maxPayloadChars) {
            throw IllegalStateException("Скриншот превышает допустимый лимит размера перед отправкой в Vision API.")
        }

        var lastErr: Throwable? = null
        for (cfg in candidates) {
            try {
                val impl: VisualModelProvider = when (cfg.providerType) {
                    "gemini" -> GeminiVisualProvider(cfg, aiRouter.httpClient)
                    "ollama_local" -> OllamaVisionProvider(cfg, aiRouter.httpClient)
                    else -> OpenAiVisionProvider(cfg, aiRouter.httpClient)
                }
                val decision = impl.analyzeScreen(
                    imageBase64 = imageBase64,
                    mimeType = mimeType,
                    imageWidth = imageWidth,
                    imageHeight = imageHeight,
                    screenWidth = screenWidth,
                    screenHeight = screenHeight,
                    userGoal = userGoal,
                    accessibilitySummary = accessibilitySummary,
                    ocrSummary = ocrSummary,
                    stepHistory = stepHistory,
                    apiKey = aiRouter.keyStore.getApiKey(cfg.id)
                )
                costGuard.recordVisionCall()
                return decision to cfg.modelName
            } catch (t: Throwable) {
                lastErr = t
            }
        }
        throw IllegalStateException("Все мультимодальные модели недоступны: ${lastErr?.message ?: "ошибка"}")
    }
}
