package com.bobai.assistant.system.vision

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

data class OcrTextBlock(
    val text: String,
    val bounds: Rect?,
    val centerX: Int,
    val centerY: Int
)

class OcrEngine {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun extractTextBlocks(
        bitmap: Bitmap,
        screenWidth: Int,
        screenHeight: Int
    ): List<OcrTextBlock> = suspendCancellableCoroutine { cont ->
        val input = InputImage.fromBitmap(bitmap, 0)
        val scaleX = screenWidth.toFloat() / bitmap.width.coerceAtLeast(1)
        val scaleY = screenHeight.toFloat() / bitmap.height.coerceAtLeast(1)

        recognizer.process(input)
            .addOnSuccessListener { visionText ->
                val blocks = visionText.textBlocks.mapNotNull { block ->
                    val cleaned = block.text.trim().replace("\n", " ")
                    if (cleaned.isBlank()) return@mapNotNull null
                    val box = block.boundingBox
                    val cx = ((box?.centerX() ?: 0) * scaleX).toInt()
                    val cy = ((box?.centerY() ?: 0) * scaleY).toInt()
                    OcrTextBlock(cleaned, box, cx, cy)
                }
                if (cont.isActive) cont.resume(blocks)
            }
            .addOnFailureListener {
                if (cont.isActive) cont.resume(emptyList())
            }
    }

    fun formatOcrSummary(blocks: List<OcrTextBlock>, limit: Int = 35): String {
        if (blocks.isEmpty()) return ""
        return blocks.take(limit).joinToString("\n") {
            "\"${it.text}\" @ (${it.centerX},${it.centerY})"
        }
    }

    fun close() {
        runCatching { recognizer.close() }
    }
}
