package com.bobai.assistant.system.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.Executors
import kotlin.coroutines.resume

data class UiRect(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
) {
    val centerX: Int get() = (left + right) / 2
    val centerY: Int get() = (top + bottom) / 2
    val width: Int get() = (right - left).coerceAtLeast(0)
    val height: Int get() = (bottom - top).coerceAtLeast(0)

    fun contains(x: Int, y: Int): Boolean = x in left..right && y in top..bottom
}

data class UiNodeSnapshot(
    val viewId: String,
    val className: String,
    val text: String,
    val contentDescription: String,
    val clickable: Boolean,
    val editable: Boolean,
    val scrollable: Boolean,
    val visibleToUser: Boolean,
    val bounds: UiRect
)

class BobAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: BobAccessibilityService? = null
            private set

        @Volatile
        var lastPackageName: String = ""
            private set

        @Volatile
        var lastEventTimestamp: Long = 0L
            private set
    }

    private val screenshotExecutor = Executors.newSingleThreadExecutor()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event?.packageName?.toString()?.let { pkg ->
            if (pkg.isNotBlank()) lastPackageName = pkg
        }
        lastEventTimestamp = System.currentTimeMillis()
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (instance === this) instance = null
        screenshotExecutor.shutdownNow()
        super.onDestroy()
    }

    fun inspectCurrentScreen(): List<UiNodeSnapshot> {
        val root = rootInActiveWindow ?: return emptyList()
        val collected = mutableListOf<UiNodeSnapshot>()
        traverse(root, collected, 0)
        return collected
    }

    fun formatTreeSummary(limit: Int = 45): String {
        val nodes = inspectCurrentScreen().filter { it.visibleToUser }.take(limit)
        if (nodes.isEmpty()) return ""
        return nodes.joinToString("\n") { n ->
            val label = n.text.ifBlank { n.contentDescription }.ifBlank { n.viewId }
            val flags = buildList {
                if (n.clickable) add("clickable")
                if (n.editable) add("editable")
                if (n.scrollable) add("scrollable")
            }.joinToString(",")
            "[$label | id=${n.viewId} | $flags | center=(${n.bounds.centerX},${n.bounds.centerY})]"
        }
    }

    private fun traverse(
        node: AccessibilityNodeInfo?,
        out: MutableList<UiNodeSnapshot>,
        depth: Int
    ) {
        if (node == null || depth > 16 || out.size >= 100) return
        val rect = Rect()
        node.getBoundsInScreen(rect)
        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        val id = node.viewIdResourceName.orEmpty()
        if (text.isNotEmpty() || desc.isNotEmpty() || node.isClickable || node.isEditable || node.isScrollable) {
            out.add(
                UiNodeSnapshot(
                    viewId = id,
                    className = node.className?.toString().orEmpty(),
                    text = text,
                    contentDescription = desc,
                    clickable = node.isClickable,
                    editable = node.isEditable,
                    scrollable = node.isScrollable,
                    visibleToUser = node.isVisibleToUser,
                    bounds = UiRect(rect.left, rect.top, rect.right, rect.bottom)
                )
            )
        }
        for (i in 0 until node.childCount) {
            traverse(node.getChild(i), out, depth + 1)
        }
    }

    fun clickByQuery(query: String): Boolean {
        if (query.isBlank()) return false
        val root = rootInActiveWindow ?: return false
        val target = findNode(root) { node ->
            val t = node.text?.toString().orEmpty()
            val d = node.contentDescription?.toString().orEmpty()
            val id = node.viewIdResourceName.orEmpty()
            node.isVisibleToUser && (t.contains(query, ignoreCase = true) ||
                d.contains(query, ignoreCase = true) ||
                id.equals(query, ignoreCase = true))
        } ?: return false

        var clickableNode: AccessibilityNodeInfo? = target
        while (clickableNode != null && !clickableNode.isClickable) {
            clickableNode = clickableNode.parent
        }
        return (clickableNode ?: target).performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    fun findNodeAtCoordinates(x: Int, y: Int): UiNodeSnapshot? {
        return inspectCurrentScreen()
            .filter { it.visibleToUser && (it.clickable || it.editable) && it.bounds.contains(x, y) }
            .minByOrNull { it.bounds.width.toLong() * it.bounds.height.toLong() }
    }

    fun inputText(query: String, textToType: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = findNode(root) { node ->
            if (!node.isEditable || !node.isVisibleToUser) return@findNode false
            if (query.isBlank()) return@findNode true
            val t = node.text?.toString().orEmpty()
            val d = node.contentDescription?.toString().orEmpty()
            val id = node.viewIdResourceName.orEmpty()
            t.contains(query, ignoreCase = true) ||
                d.contains(query, ignoreCase = true) ||
                id.equals(query, ignoreCase = true)
        } ?: root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
            ?: return false

        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, textToType)
        }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scrollSemantic(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val scrollable = findNode(root) { it.isScrollable && it.isVisibleToUser } ?: return false
        val action = if (forward) {
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        } else {
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        }
        return scrollable.performAction(action)
    }

    suspend fun tapAt(x: Int, y: Int): Boolean {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 65L))
            .build()
        return dispatchGestureAwait(gesture)
    }

    suspend fun doubleTapAt(x: Int, y: Int): Boolean {
        val p1 = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val p2 = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p1, 0L, 55L))
            .addStroke(GestureDescription.StrokeDescription(p2, 110L, 55L))
            .build()
        return dispatchGestureAwait(gesture)
    }

    suspend fun longPressAt(x: Int, y: Int, durationMs: Long = 650L): Boolean {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs.coerceIn(450L, 2000L)))
            .build()
        return dispatchGestureAwait(gesture)
    }

    suspend fun swipe(
        startX: Int,
        startY: Int,
        endX: Int,
        endY: Int,
        durationMs: Long = 340L
    ): Boolean {
        val path = Path().apply {
            moveTo(startX.toFloat(), startY.toFloat())
            lineTo(endX.toFloat(), endY.toFloat())
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs.coerceIn(150L, 1200L)))
            .build()
        return dispatchGestureAwait(gesture)
    }

    suspend fun scrollGesture(direction: String, screenWidth: Int, screenHeight: Int): Boolean {
        val cx = screenWidth / 2
        val cy = screenHeight / 2
        return when (direction.lowercase()) {
            "up" -> swipe(cx, (screenHeight * 0.28f).toInt(), cx, (screenHeight * 0.78f).toInt())
            "left" -> swipe((screenWidth * 0.2f).toInt(), cy, (screenWidth * 0.85f).toInt(), cy)
            "right" -> swipe((screenWidth * 0.85f).toInt(), cy, (screenWidth * 0.2f).toInt(), cy)
            else -> swipe(cx, (screenHeight * 0.76f).toInt(), cx, (screenHeight * 0.26f).toInt())
        }
    }

    private suspend fun dispatchGestureAwait(gesture: GestureDescription): Boolean =
        suspendCancellableCoroutine { cont ->
            val accepted = dispatchGesture(
                gesture,
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (cont.isActive) cont.resume(true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (cont.isActive) cont.resume(false)
                    }
                },
                null
            )
            if (!accepted && cont.isActive) {
                cont.resume(false)
            }
        }

    suspend fun takeAccessibilityScreenshot(): Bitmap? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        return suspendCancellableCoroutine { cont ->
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                screenshotExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        val bmp = runCatching {
                            val hw = Bitmap.wrapHardwareBuffer(
                                screenshot.hardwareBuffer,
                                screenshot.colorSpace
                            )
                            val copy = hw?.copy(Bitmap.Config.ARGB_8888, false)
                            hw?.recycle()
                            screenshot.hardwareBuffer.close()
                            copy
                        }.getOrNull()
                        if (cont.isActive) cont.resume(bmp)
                    }

                    override fun onFailure(errorCode: Int) {
                        if (cont.isActive) cont.resume(null)
                    }
                }
            )
        }
    }

    fun navigateBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun navigateHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun navigateRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun openNotificationsShade(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun openQuickSettings(): Boolean = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)

    private fun findNode(
        node: AccessibilityNodeInfo?,
        predicate: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (node == null) return null
        if (predicate(node)) return node
        for (i in 0 until node.childCount) {
            val found = findNode(node.getChild(i), predicate)
            if (found != null) return found
        }
        return null
    }
}
