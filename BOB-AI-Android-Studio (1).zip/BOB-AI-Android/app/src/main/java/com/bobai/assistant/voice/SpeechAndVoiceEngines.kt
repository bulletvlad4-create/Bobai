package com.bobai.assistant.voice

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

data class VoiceOption(
    val name: String,
    val localeTag: String,
    val isNetworkRequired: Boolean
)

class SpeechEngine(private val context: Context) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening

    private val _wakeWordModeActive = MutableStateFlow(false)
    val wakeWordModeActive: StateFlow<Boolean> = _wakeWordModeActive

    private val _partialText = MutableStateFlow("")
    val partialText: StateFlow<String> = _partialText

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun startListening(
        onFinalResult: (String) -> Unit,
        onError: (String) -> Unit,
        onBargeInDetected: () -> Unit = {}
    ) {
        mainHandler.post {
            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                val msg = "Системное распознавание речи (Google Speech / Speech Services) недоступно на устройстве."
                _lastError.value = msg
                onError(msg)
                return@post
            }
            stopListeningInternal()
            _lastError.value = null
            recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _isListening.value = true
                    }

                    override fun onBeginningOfSpeech() {
                        onBargeInDetected()
                    }

                    override fun onRmsChanged(rmsdB: Float) = Unit
                    override fun onBufferReceived(buffer: ByteArray?) = Unit
                    override fun onEndOfSpeech() {
                        _isListening.value = false
                    }

                    override fun onError(error: Int) {
                        _isListening.value = false
                        val humanErr = mapSpeechError(error)
                        _lastError.value = humanErr
                        onError(humanErr)
                    }

                    override fun onResults(results: Bundle?) {
                        _isListening.value = false
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull().orEmpty().trim()
                        _partialText.value = ""
                        if (text.isNotBlank()) {
                            onFinalResult(text)
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val text = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            .orEmpty()
                        _partialText.value = text
                        if (text.isNotBlank()) {
                            onBargeInDetected()
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) = Unit
                })
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ru-RU")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer?.startListening(intent)
        }
    }

    /**
     * Foreground/active-session wake-word listener for "Привет, Боб".
     * Honest note: Android 12+ restricts background hotword capture from non-system apps
     * when the screen is off, so this mode operates while the app or active service session runs.
     */
    fun startWakeWordLoop(
        onCommandExtracted: (String) -> Unit,
        onWakeOnlyDetected: () -> Unit,
        onBargeInDetected: () -> Unit,
        onStatusMessage: (String) -> Unit
    ) {
        _wakeWordModeActive.value = true
        listenWakeWordCycle(onCommandExtracted, onWakeOnlyDetected, onBargeInDetected, onStatusMessage)
    }

    private fun listenWakeWordCycle(
        onCommandExtracted: (String) -> Unit,
        onWakeOnlyDetected: () -> Unit,
        onBargeInDetected: () -> Unit,
        onStatusMessage: (String) -> Unit
    ) {
        if (!_wakeWordModeActive.value) return
        startListening(
            onFinalResult = { recognized ->
                val stripped = WakeWordMatcher.extractCommandAfterWakeWord(recognized)
                if (stripped != null) {
                    if (stripped.isBlank()) {
                        onWakeOnlyDetected()
                    } else {
                        onCommandExtracted(stripped)
                    }
                } else if (_wakeWordModeActive.value) {
                    mainHandler.postDelayed({
                        listenWakeWordCycle(onCommandExtracted, onWakeOnlyDetected, onBargeInDetected, onStatusMessage)
                    }, 350L)
                }
            },
            onError = { err ->
                onStatusMessage(err)
                if (_wakeWordModeActive.value) {
                    mainHandler.postDelayed({
                        listenWakeWordCycle(onCommandExtracted, onWakeOnlyDetected, onBargeInDetected, onStatusMessage)
                    }, 1200L)
                }
            },
            onBargeInDetected = onBargeInDetected
        )
    }

    fun stopWakeWordLoop() {
        _wakeWordModeActive.value = false
        stopListening()
    }

    fun stopListening() {
        mainHandler.post { stopListeningInternal() }
    }

    private fun stopListeningInternal() {
        _isListening.value = false
        runCatching {
            recognizer?.stopListening()
            recognizer?.destroy()
        }
        recognizer = null
    }

    private fun mapSpeechError(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_AUDIO -> "Ошибка аудиозаписи микрофона."
        SpeechRecognizer.ERROR_CLIENT -> "Внутренняя ошибка клиента распознавания."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Нет разрешения RECORD_AUDIO для микрофона."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Нет сети для облачного распознавания речи."
        SpeechRecognizer.ERROR_NO_MATCH -> "Речь не распознана, повторите команду."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Распознаватель речи занят, перезапуск..."
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Истекло время ожидания речи."
        else -> "Ошибка распознавания речи (код $code)."
    }
}

object WakeWordMatcher {
    private val wakePatterns = listOf(
        Regex("^\\s*(?:эй\\s+)?привет[,.!\\s]+боб[,:\\s-]*", RegexOption.IGNORE_CASE),
        Regex("^\\s*боб[,:\\s-]+", RegexOption.IGNORE_CASE),
        Regex("^\\s*слушай[,.!\\s]+боб[,:\\s-]*", RegexOption.IGNORE_CASE)
    )

    fun extractCommandAfterWakeWord(transcript: String): String? {
        val trimmed = transcript.trim()
        if (trimmed.equals("привет боб", ignoreCase = true) ||
            trimmed.equals("привет, боб", ignoreCase = true) ||
            trimmed.equals("боб", ignoreCase = true)
        ) {
            return ""
        }
        for (regex in wakePatterns) {
            if (regex.containsMatchIn(trimmed)) {
                return trimmed.replaceFirst(regex, "").trim()
            }
        }
        return null
    }
}

class VoiceEngine(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("bob_ai_voice_prefs", Context.MODE_PRIVATE)

    private var tts: TextToSpeech? = null
    private var isReady = false
    private var speechRate = prefs.getFloat("speech_rate", 1.05f)
    private var selectedVoiceName = prefs.getString("voice_name", "") ?: ""
    private var onSpeechFinishedCallback: (() -> Unit)? = null

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking

    private val _availableVoices = MutableStateFlow<List<VoiceOption>>(emptyList())
    val availableVoices: StateFlow<List<VoiceOption>> = _availableVoices

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("ru", "RU")
                tts?.setSpeechRate(speechRate)
                refreshRussianVoices()
                if (selectedVoiceName.isNotBlank()) {
                    applyVoiceByName(selectedVoiceName)
                }
                isReady = true
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                _isSpeaking.value = true
            }

            override fun onDone(utteranceId: String?) {
                _isSpeaking.value = false
                onSpeechFinishedCallback?.invoke()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                _isSpeaking.value = false
            }
        })
    }

    private fun refreshRussianVoices() {
        val ruVoices = runCatching {
            tts?.voices
                ?.filter { it.locale.language.equals("ru", ignoreCase = true) }
                ?.sortedBy { it.isNetworkConnectionRequired }
                ?.map { VoiceOption(it.name, it.locale.toLanguageTag(), it.isNetworkConnectionRequired) }
                .orEmpty()
        }.getOrDefault(emptyList())
        _availableVoices.value = ruVoices
    }

    fun getRate(): Float = speechRate

    fun setRate(rate: Float) {
        speechRate = rate.coerceIn(0.6f, 1.8f)
        prefs.edit().putFloat("speech_rate", speechRate).apply()
        tts?.setSpeechRate(speechRate)
    }

    fun getSelectedVoiceName(): String = selectedVoiceName

    fun applyVoiceByName(name: String) {
        selectedVoiceName = name
        prefs.edit().putString("voice_name", name).apply()
        val match: Voice? = runCatching { tts?.voices?.firstOrNull { it.name == name } }.getOrNull()
        if (match != null) {
            tts?.voice = match
        }
    }

    fun speak(text: String, onDone: (() -> Unit)? = null) {
        onSpeechFinishedCallback = onDone
        if (!isReady || text.isBlank()) {
            onDone?.invoke()
            return
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "bob_${System.currentTimeMillis()}")
    }

    fun interruptImmediately() {
        onSpeechFinishedCallback = null
        tts?.stop()
        _isSpeaking.value = false
    }

    fun shutdown() {
        onSpeechFinishedCallback = null
        tts?.stop()
        tts?.shutdown()
    }
}
