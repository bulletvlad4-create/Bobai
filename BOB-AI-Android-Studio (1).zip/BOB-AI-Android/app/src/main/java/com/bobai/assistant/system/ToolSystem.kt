package com.bobai.assistant.system

import android.Manifest
import android.app.NotificationManager
import android.bluetooth.BluetoothManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.bobai.assistant.domain.model.OnboardingPermissionStatus
import com.bobai.assistant.domain.model.ToolResult
import com.bobai.assistant.system.accessibility.BobAccessibilityService
import com.bobai.assistant.system.notification.BobNotificationListenerService
import com.bobai.assistant.system.vision.ScreenCaptureManager
import com.bobai.assistant.system.vpn.BobVpnService
import java.io.File

data class InstalledAppItem(
    val packageName: String,
    val label: String
)

data class FoundFileItem(
    val name: String,
    val path: String,
    val mimeType: String,
    val modifiedAt: Long
)

class ToolSystem(
    private val context: Context,
    private val captureManager: ScreenCaptureManager
) {

    fun listInstalledApps(): List<InstalledAppItem> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }
        return resolved.map {
            InstalledAppItem(
                packageName = it.activityInfo.packageName,
                label = it.loadLabel(pm).toString()
            )
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
    }

    fun launchApp(appQuery: String): ToolResult {
        if (appQuery.isBlank()) {
            return ToolResult(false, false, "Не указано название приложения для запуска.")
        }
        val apps = listInstalledApps()
        val match = apps.firstOrNull {
            it.label.equals(appQuery, ignoreCase = true) ||
                it.packageName.equals(appQuery, ignoreCase = true)
        } ?: apps.firstOrNull {
            it.label.contains(appQuery, ignoreCase = true) ||
                it.packageName.contains(appQuery, ignoreCase = true)
        } ?: return ToolResult(false, false, "Приложение «$appQuery» не найдено среди установленных.")

        val launchIntent = context.packageManager.getLaunchIntentForPackage(match.packageName)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ?: return ToolResult(false, false, "У «${match.label}» нет точки входа для запуска.")

        context.startActivity(launchIntent)
        return ToolResult(true, true, "Запущено приложение «${match.label}» (${match.packageName}).", match.packageName)
    }

    fun openSettings(section: String): ToolResult {
        val action = when (section.lowercase()) {
            "wifi", "wi-fi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "vpn" -> Settings.ACTION_VPN_SETTINGS
            "display", "экран", "дисплей" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound", "звук" -> Settings.ACTION_SOUND_SETTINGS
            "mobile", "сеть", "мобильная сеть" -> Settings.ACTION_NETWORK_OPERATOR_SETTINGS
            "accessibility", "спецвозможности" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "notifications", "уведомления" -> Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS
            "battery", "энергосбережение" -> Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        val intent = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return ToolResult(true, true, "Открыты системные настройки: $section.")
    }

    fun setMediaVolume(percent: Int): ToolResult {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val clamped = percent.coerceIn(0, 100)
        val target = (max * clamped / 100f).toInt()
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
        val actual = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        return ToolResult(true, actual == target, "Громкость мультимедиа установлена на $clamped% ($actual/$max).")
    }

    fun setBrightness(percent: Int): ToolResult {
        if (!Settings.System.canWrite(context)) {
            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            return ToolResult(false, false, "Требуется разрешение WRITE_SETTINGS. Открыт системный экран.")
        }
        val clamped = percent.coerceIn(5, 100)
        val value = (255 * clamped / 100f).toInt()
        Settings.System.putInt(
            context.contentResolver,
            Settings.System.SCREEN_BRIGHTNESS_MODE,
            Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
        )
        Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, value)
        return ToolResult(true, true, "Яркость экрана установлена на $clamped%.")
    }

    fun toggleFlashlight(enabled: Boolean): ToolResult {
        return runCatching {
            val cam = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cam.cameraIdList.firstOrNull() ?: error("Камера со вспышкой не найдена")
            cam.setTorchMode(id, enabled)
            ToolResult(true, true, if (enabled) "Фонарик включён." else "Фонарик выключен.")
        }.getOrElse {
            ToolResult(false, false, "Ошибка управления фонариком: ${it.message}")
        }
    }

    fun toggleDnd(enabled: Boolean): ToolResult {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            return ToolResult(false, false, "Требуется доступ к управлению «Не беспокоить». Открыты настройки.")
        }
        nm.setInterruptionFilter(
            if (enabled) NotificationManager.INTERRUPTION_FILTER_PRIORITY
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
        return ToolResult(true, true, if (enabled) "Режим «Не беспокоить» включён." else "Режим «Не беспокоить» выключен.")
    }

    fun openWifiPanel(): ToolResult {
        val action = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            Settings.Panel.ACTION_WIFI
        } else {
            Settings.ACTION_WIFI_SETTINGS
        }
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ToolResult(
            true,
            true,
            "Открыта официальная системная панель Wi-Fi (Android 10+ запрещает скрытое переключение Wi-Fi сторонними приложениями)."
        )
    }

    fun manageBluetooth(enable: Boolean): ToolResult {
        val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter = btManager?.adapter
            ?: return ToolResult(false, false, "Bluetooth-адаптер не найден на устройстве.")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // On Android 13+, BluetoothAdapter.enable/disable are deprecated & blocked for non-system apps.
            // Open Bluetooth settings so Visual Agent or user can toggle cleanly.
            openSettings("bluetooth")
            return ToolResult(
                true,
                false,
                "Открыты настройки Bluetooth (Android 13+ требует подтверждения в системных настройках; Visual Agent может нажать переключатель)."
            )
        }

        val hasLegacyOrConnectPerm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
        if (!hasLegacyOrConnectPerm) {
            openSettings("bluetooth")
            return ToolResult(false, false, "Нет разрешения BLUETOOTH_CONNECT. Открыты настройки Bluetooth.")
        }

        @Suppress("DEPRECATION")
        val ok = if (enable) adapter.enable() else adapter.disable()
        return if (ok) {
            ToolResult(true, true, if (enable) "Bluetooth включён." else "Bluetooth выключен.")
        } else {
            openSettings("bluetooth")
            ToolResult(true, false, "Система ограничила прямое изменение Bluetooth; открыты системные настройки.")
        }
    }

    fun checkNetwork(): ToolResult {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val caps = cm.getNetworkCapabilities(network)
        val connected = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val validated = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        val wifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        val cellular = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        val vpnActive = caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true || BobVpnService.isRunning
        val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val btOn = runCatching { btManager?.adapter?.isEnabled == true }.getOrDefault(false)
        val transport = when {
            wifi -> "Wi-Fi"
            cellular -> "Мобильная сеть"
            else -> "Нет активного транспорта"
        }
        return ToolResult(
            success = connected,
            verified = true,
            message = "Интернет: ${if (connected) "есть (${if (validated) "проверен" else "без проверки"}, $transport)" else "нет"}, VPN: ${if (vpnActive) "активен" else "выкл"}, Bluetooth: ${if (btOn) "вкл" else "выкл"}."
        )
    }

    fun listInstalledThirdPartyVpnClients(): List<InstalledAppItem> {
        val knownVpnPackages = setOf(
            "com.wireguard.android",
            "de.blinkt.openvpn",
            "net.openvpn.openvpn",
            "org.amnezia.vpn",
            "ch.protonvpn.android",
            "org.getoutline.android.client",
            "com.cloudflare.onedotonedotonedotone"
        )
        return listInstalledApps().filter { app ->
            app.packageName in knownVpnPackages || app.label.contains("vpn", ignoreCase = true)
        }
    }

    fun toggleVpn(enabled: Boolean, clientHint: String = ""): ToolResult {
        if (clientHint.isNotBlank() && !clientHint.equals("BobVpnService", ignoreCase = true)) {
            val clients = listInstalledThirdPartyVpnClients()
            val targetClient = clients.firstOrNull {
                it.label.contains(clientHint, ignoreCase = true) ||
                    it.packageName.contains(clientHint, ignoreCase = true)
            }
            if (targetClient != null) {
                val launch = context.packageManager.getLaunchIntentForPackage(targetClient.packageName)
                    ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (launch != null) {
                    context.startActivity(launch)
                    return ToolResult(
                        true,
                        false,
                        "Открыт сторонний VPN-клиент «${targetClient.label}». Сторонние VPN не разрешают внешнее управление туннелем без явного API; Visual Agent может нажать кнопку подключения на экране."
                    )
                }
            }
            return ToolResult(
                false,
                false,
                "Сторонний VPN-клиент «$clientHint» не найден или не предоставляет API автоматического включения."
            )
        }

        if (!enabled) {
            val stopIntent = Intent(context, BobVpnService::class.java).apply {
                action = BobVpnService.ACTION_STOP
            }
            context.startService(stopIntent)
            return ToolResult(true, true, "Встроенный VPN-сервис BobVpnService остановлен.")
        }

        val prepare = VpnService.prepare(context)
        if (prepare != null) {
            prepare.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(prepare)
            return ToolResult(
                false,
                false,
                "Требуется системное согласие пользователя на включение встроенного Android VpnService."
            )
        }

        val startIntent = Intent(context, BobVpnService::class.java).apply {
            action = BobVpnService.ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(startIntent)
        } else {
            context.startService(startIntent)
        }
        return ToolResult(true, true, "Встроенный туннель BobVpnService запущен (10.8.0.2, DNS 1.1.1.1).")
    }

    fun controlMedia(action: String): ToolResult {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val keyCode = when (action.lowercase()) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous", "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        return ToolResult(true, true, "Отправлена медиа-команда: $action.")
    }

    fun readRecentNotifications(limit: Int = 10): ToolResult {
        if (!BobNotificationListenerService.isConnected) {
            return ToolResult(
                false,
                false,
                "Служба NotificationListenerService не включена. Предоставьте доступ к уведомлениям в разделе «Система»."
            )
        }
        val items = BobNotificationListenerService.getRecentNotifications().take(limit)
        if (items.isEmpty()) {
            return ToolResult(true, true, "Недавних уведомлений пока нет.")
        }
        val summary = items.joinToString("\n") {
            "• [${it.packageName}] ${it.title}: ${it.text}"
        }
        return ToolResult(true, true, "Последние уведомления (${items.size}):\n$summary", summary)
    }

    fun searchFiles(query: String): List<FoundFileItem> {
        val results = mutableListOf<FoundFileItem>()
        val appDocsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.filesDir
        appDocsDir.listFiles()?.filter {
            query.isBlank() || it.name.contains(query, ignoreCase = true)
        }?.take(10)?.forEach { file ->
            results.add(
                FoundFileItem(
                    name = file.name,
                    path = file.absolutePath,
                    mimeType = if (file.extension == "md" || file.extension == "txt") "text/plain" else "application/octet-stream",
                    modifiedAt = file.lastModified() / 1000L
                )
            )
        }

        val projection = arrayOf(
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.DATA,
            MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Files.FileColumns.DATE_MODIFIED
        )
        val selection = if (query.isBlank()) null else "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE ?"
        val args = if (query.isBlank()) null else arrayOf("%$query%")
        runCatching {
            context.contentResolver.query(
                MediaStore.Files.getContentUri("external"),
                projection,
                selection,
                args,
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val pathCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED)
                while (cursor.moveToNext() && results.size < 20) {
                    val path = cursor.getString(pathCol).orEmpty()
                    if (results.none { it.path == path }) {
                        results.add(
                            FoundFileItem(
                                name = cursor.getString(nameCol).orEmpty(),
                                path = path,
                                mimeType = cursor.getString(mimeCol) ?: "application/octet-stream",
                                modifiedAt = cursor.getLong(dateCol)
                            )
                        )
                    }
                }
            }
        }
        return results
    }

    fun openFile(query: String): ToolResult {
        val found = searchFiles(query).firstOrNull()
            ?: return ToolResult(false, false, "Файл «$query» не найден.")
        val file = File(found.path)
        if (!file.exists()) {
            return ToolResult(false, false, "Файл недоступен по пути ${found.path}.")
        }
        return runCatching {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, found.mimeType)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(intent)
            ToolResult(true, true, "Открыт файл «${found.name}».", found.path)
        }.getOrElse {
            ToolResult(false, false, "Нет системного приложения или доступа к пути ${found.path}: ${it.message}")
        }
    }

    fun shareFile(query: String): ToolResult {
        val found = searchFiles(query).firstOrNull()
            ?: return ToolResult(false, false, "Файл «$query» не найден для отправки.")
        val file = File(found.path)
        if (!file.exists()) {
            return ToolResult(false, false, "Файл ${found.name} недоступен для чтения.")
        }
        return runCatching {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = found.mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, "Отправить ${found.name}").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
            ToolResult(true, true, "Открыто системное меню отправки для «${found.name}».")
        }.getOrElse {
            ToolResult(false, false, "Ошибка подготовки отправки файла: ${it.message}")
        }
    }

    fun deleteAppFile(query: String): ToolResult {
        val appDocsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.filesDir
        val target = appDocsDir.listFiles()?.firstOrNull {
            it.name.equals(query, ignoreCase = true) || it.name.contains(query, ignoreCase = true)
        } ?: return ToolResult(false, false, "Файл «$query» не найден в безопасном хранилище заметок.")
        val deleted = target.delete()
        return ToolResult(deleted, !target.exists(), if (deleted) "Файл «${target.name}» удалён." else "Не удалось удалить файл.")
    }

    fun createNoteFile(title: String, content: String): ToolResult {
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.filesDir
        val safeName = title.replace(Regex("[^a-zA-Zа-яА-Я0-9_-]"), "_").ifBlank { "note" }
        val file = File(dir, "$safeName.md")
        file.writeText(content)
        return ToolResult(true, file.exists(), "Создана заметка ${file.name} (${file.absolutePath}).", file.absolutePath)
    }

    fun inspectAccessibility(): ToolResult {
        val service = BobAccessibilityService.instance
            ?: return ToolResult(false, false, "Служба AccessibilityService не включена пользователем.")
        val nodes = service.inspectCurrentScreen()
        return ToolResult(
            success = true,
            verified = true,
            message = "На экране ${BobAccessibilityService.lastPackageName} найдено ${nodes.size} доступных элементов интерфейса."
        )
    }

    fun accessibilityTap(target: String): ToolResult {
        val service = BobAccessibilityService.instance
            ?: return ToolResult(false, false, "Служба AccessibilityService не включена.")
        val ok = service.clickByQuery(target)
        return ToolResult(ok, ok, if (ok) "Нажато: «$target»." else "Элемент «$target» не найден в дереве UI.")
    }

    fun accessibilityInput(target: String, text: String): ToolResult {
        val service = BobAccessibilityService.instance
            ?: return ToolResult(false, false, "Служба AccessibilityService не включена.")
        val ok = service.inputText(target, text)
        return ToolResult(ok, ok, if (ok) "Введён текст в поле «$target»." else "Поле ввода не найдено.")
    }

    fun accessibilityBack(): ToolResult {
        val service = BobAccessibilityService.instance
            ?: return ToolResult(false, false, "Служба AccessibilityService не включена.")
        val ok = service.navigateBack()
        return ToolResult(ok, ok, if (ok) "Выполнен возврат назад." else "Не удалось выполнить возврат.")
    }

    fun openBatteryOptimizationSettings(): ToolResult {
        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = Uri.parse("package:${context.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return ToolResult(true, true, "Открыт запрос отключения оптимизации батареи (важно для OxygenOS / MIUI / OneUI).")
    }

    fun getOnboardingPermissions(): List<OnboardingPermissionStatus> {
        val mic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val notifications = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else true
        val accEnabled = BobAccessibilityService.instance != null || isAccessibilityEnabledInSettings()
        val mediaProj = captureManager.hasMediaProjectionConsent.value
        val notifListener = BobNotificationListenerService.isConnected
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val dnd = nm.isNotificationPolicyAccessGranted
        val writeSettings = Settings.System.canWrite(context)
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val batteryUnrestricted = pm.isIgnoringBatteryOptimizations(context.packageName)
        val overlay = Settings.canDrawOverlays(context)

        return listOf(
            OnboardingPermissionStatus(
                id = "microphone",
                title = "Микрофон (RECORD_AUDIO)",
                rationale = "Нужен для распознавания русской речи, перебивания и активации по фразе «Привет, Боб».",
                granted = mic,
                requiredForCore = true
            ),
            OnboardingPermissionStatus(
                id = "accessibility",
                title = "Специальные возможности (AccessibilityService)",
                rationale = "Позволяет читать UI-дерево и выполнять нажатия, двойные/долгие тапы, свайпы, прокрутку и ввод текста.",
                granted = accEnabled,
                requiredForCore = true,
                oemHint = "OxygenOS/Android 13+: если переключатель заблокирован, откройте Информация о приложении -> три точки -> Разрешить ограниченные настройки."
            ),
            OnboardingPermissionStatus(
                id = "media_projection",
                title = "Захват экрана (MediaProjection API)",
                rationale = "Критически важно для Visual Agent: получение реальных скриншотов экрана для ИИ-анализа и координат.",
                granted = mediaProj,
                requiredForCore = true
            ),
            OnboardingPermissionStatus(
                id = "notifications_post",
                title = "Показ уведомлений (POST_NOTIFICATIONS)",
                rationale = "Необходимо для постоянного фонового сервиса быстрого доступа и уведомлений Visual Agent.",
                granted = notifications,
                requiredForCore = true
            ),
            OnboardingPermissionStatus(
                id = "notification_listener",
                title = "Чтение уведомлений и медиа",
                rationale = "Позволяет Бобу читать входящие уведомления и видеть активный медиаплеер.",
                granted = notifListener,
                requiredForCore = false
            ),
            OnboardingPermissionStatus(
                id = "dnd",
                title = "Режим «Не беспокоить»",
                rationale = "Разрешает включать и отключать режим тишины (например, при подготовке телефона к игре).",
                granted = dnd,
                requiredForCore = false
            ),
            OnboardingPermissionStatus(
                id = "write_settings",
                title = "Изменение системных настроек (WRITE_SETTINGS)",
                rationale = "Требуется для точной регулировки яркости экрана.",
                granted = writeSettings,
                requiredForCore = false
            ),
            OnboardingPermissionStatus(
                id = "battery",
                title = "Работа в фоне без ограничений",
                rationale = "Предотвращает выгрузку фонового сервиса и Accessibility/VPN при блокировке экрана.",
                granted = batteryUnrestricted,
                requiredForCore = true,
                oemHint = "На OnePlus/OxygenOS также закрепите BOB AI в меню недавних приложений и отключите «Приостановку неактивного приложения»."
            ),
            OnboardingPermissionStatus(
                id = "overlay",
                title = "Поверх других окон (Overlay)",
                rationale = "Опционально для плавающего индикатора визуального анализа экрана.",
                granted = overlay,
                requiredForCore = false
            )
        )
    }

    private fun isAccessibilityEnabledInSettings(): Boolean {
        val expected = ComponentName(context, BobAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ).orEmpty()
        return enabled.contains(expected, ignoreCase = true)
    }
}
