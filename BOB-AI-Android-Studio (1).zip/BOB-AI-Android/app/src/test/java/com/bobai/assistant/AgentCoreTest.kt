package com.bobai.assistant

import com.bobai.assistant.domain.agent.SecurityManager
import com.bobai.assistant.domain.agent.SelfCorrectionNormalizer
import com.bobai.assistant.domain.brain.JsonExtractionUtils
import com.bobai.assistant.domain.model.PlannedStep
import com.bobai.assistant.domain.model.RiskLevel
import com.bobai.assistant.domain.model.VisualDecision
import com.bobai.assistant.voice.WakeWordMatcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AgentCoreTest {

    @Test
    fun securityManagerFlagsDestructiveAndFinancialTools() {
        val security = SecurityManager()
        val deleteStep = PlannedStep(
            id = "1",
            tool = "delete_file",
            params = mapOf("fileName" to "notes.txt"),
            humanLabel = "Удалить файл"
        )
        assertEquals(RiskLevel.CRITICAL, security.assessRisk(deleteStep, "удали файл"))

        val shareStep = PlannedStep(
            id = "2",
            tool = "share_file",
            params = mapOf("query" to "отчёт.pdf"),
            humanLabel = "Отправить документ"
        )
        assertEquals(RiskLevel.CRITICAL, security.assessRisk(shareStep, "отправь отчёт"))

        val visualPayment = VisualDecision(
            screenDescription = "Банковское окно",
            action = "tap",
            targetText = "Оплатить покупку",
            reason = "Нажатие оплатить"
        )
        assertNotNull(security.inspectVisualDecisionForRisk(visualPayment))
    }

    @Test
    fun securityManagerRespectsDisabledToolsAndKillSwitch() {
        val security = SecurityManager()
        assertTrue(security.isAllowed("launch_app"))
        security.disabledTools.add("launch_app")
        assertFalse(security.isAllowed("launch_app"))
        security.disabledTools.clear()
        security.assistantEnabled = false
        assertFalse(security.isAllowed("launch_app"))
    }

    @Test
    fun selfCorrectionNormalizerExtractsLatestIntent() {
        val result = SelfCorrectionNormalizer.normalize("Боб, открой игру, да нет, лучше сначала включи VPN")
        assertEquals("сначала включи VPN", result)
    }

    @Test
    fun wakeWordMatcherExtractsTrailingCommand() {
        assertEquals("", WakeWordMatcher.extractCommandAfterWakeWord("Привет, Боб"))
        assertEquals("включи фонарик", WakeWordMatcher.extractCommandAfterWakeWord("Привет, Боб, включи фонарик"))
        assertNull(WakeWordMatcher.extractCommandAfterWakeWord("открой браузер и найди погоду"))
    }

    @Test
    fun jsonExtractionStripsMarkdownFences() {
        val raw = """
            ```json
            {"heard":"тест","understood":"проверка","reply":"ок","steps":[]}
            ```
        """.trimIndent()
        val cleaned = JsonExtractionUtils.extractJsonObject(raw)
        assertTrue(cleaned.startsWith("{") && cleaned.endsWith("}"))
        assertFalse(cleaned.contains("```"))
    }
}
