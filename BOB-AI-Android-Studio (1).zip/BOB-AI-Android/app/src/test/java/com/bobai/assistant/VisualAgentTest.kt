package com.bobai.assistant

import com.bobai.assistant.domain.model.VisualCoordinates
import com.bobai.assistant.domain.vision.VisualDecisionValidator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class VisualAgentTest {

    @Test
    fun parsesValidVisualDecisionJson() {
        val raw = """
            {
              "screenDescription": "Открыт Telegram",
              "elements": [
                {"label": "Поиск", "role": "input", "x": 540, "y": 120, "width": 800, "height": 90, "interactive": true}
              ],
              "action": "TAP",
              "coordinates": {"x": 500, "y": 250, "space": "normalized_1000"},
              "targetText": "Поиск",
              "confidence": 0.94,
              "reason": "Нажатие на поле поиска"
            }
        """.trimIndent()

        val decision = VisualDecisionValidator.parseAndValidate(raw)
        assertEquals("tap", decision.action)
        assertEquals("Открыт Telegram", decision.screenDescription)
        assertEquals(0.94f, decision.confidence, 0.001f)
        assertEquals(1, decision.elements.size)
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsUnknownVisualAction() {
        val bad = """
            {"screenDescription":"test","action":"hack_device","confidence":0.8,"reason":"bad"}
        """.trimIndent()
        VisualDecisionValidator.parseAndValidate(bad)
    }

    @Test
    fun mapsNormalizedAndImagePixelCoordinatesAcrossOrientations() {
        // Portrait 1080x2400
        val portrait = VisualDecisionValidator.toScreenPixels(
            coords = VisualCoordinates(x = 500, y = 500, space = "normalized_1000"),
            imageWidth = 460,
            imageHeight = 1024,
            screenWidth = 1080,
            screenHeight = 2400
        )
        assertNotNull(portrait)
        assertEquals(540, portrait!!.first)
        assertEquals(1200, portrait.second)

        // Landscape 2400x1080 with image_px
        val landscape = VisualDecisionValidator.toScreenPixels(
            coords = VisualCoordinates(x = 512, y = 230, space = "image_px"),
            imageWidth = 1024,
            imageHeight = 460,
            screenWidth = 2400,
            screenHeight = 1080
        )
        assertNotNull(landscape)
        assertEquals(1200, landscape!!.first)
        assertEquals(540, landscape.second)
    }

    @Test
    fun mapsSwipeStartAndEndPoints() {
        val pts = VisualDecisionValidator.toScreenSwipePoints(
            coords = VisualCoordinates(x = 500, y = 800, endX = 500, endY = 200, space = "normalized_1000"),
            imageWidth = 500,
            imageHeight = 1000,
            screenWidth = 1000,
            screenHeight = 2000
        )
        assertNotNull(pts)
        assertTrue(pts!!.first.second > pts.second.second)
        assertEquals(500, pts.first.first)
        assertEquals(1600, pts.first.second)
        assertEquals(400, pts.second.second)
    }
}
