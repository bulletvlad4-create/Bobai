# BOB AI — Инструкция по сборке APK, установке и настройке (Android)

## 1. Архитектура Visual Agent и компонентов
BOB AI объединяет:
- **Visual Agent** (`VisualAgentEngine` + `ScreenCaptureManager` + `OcrEngine` + `VisualModelRouter`): цикл **Скриншот (`MediaProjection`) → OCR (ML Kit) + Accessibility Tree → Мультимодальная Vision-модель → Проверка безопасности → Гибридное действие (`AccessibilityNodeInfo` / `dispatchGesture`) → Новый скриншот → Проверка результата**.
- **AI Brain** (`AgentCore`): планирование многошаговых задач, нормализация самоисправлений, обратная связь при сбоях и лимиты шагов/времени.
- **Voice & Speech** (`SpeechEngine`, `VoiceEngine`, `WakeWordMatcher`): русское распознавание речи, непрерывный диалог, перебивание, выбор голоса и скорости, активация по фразе «Привет, Боб» в активной сессии.
- **Системные интеграции**: `BobAccessibilityService`, `BobScreenCaptureService`, `BobForegroundService`, `BobNotificationListenerService`, `BobVpnService`, Room (`BobDatabase`), `FileProvider`, виджет рабочего стола.

## 2. Сборка Debug APK

### Вариант А — Автоматическая сборка через GitHub Actions (рекомендуется)
1. Загрузите содержимое архива в GitHub-репозиторий (можно как в корень, так и во вложенную папку — workflow `.github/workflows/android-build.yml` автоматически найдёт `settings.gradle.kts`).
2. Откройте вкладку **Actions** → **Build BOB AI Android APK** → **Run workflow** (или выполните `git push`).
3. Workflow автоматически установит JDK 17, Android SDK 35, Gradle 8.9, прогонит `testDebugUnitTest`, соберёт `assembleDebug`, проверит наличие APK и загрузит артефакты **`BOB-AI-APK`** (`BOB-AI-debug.apk`) и **`BOB-AI-Source-ZIP`**.

### Вариант Б — Локальная сборка в Android Studio
1. Откройте папку с `settings.gradle.kts` в **Android Studio Ladybug+** (JDK 17, Android SDK 35).
2. Дождитесь синхронизации Gradle и выполните **Build → Build Bundle(s) / APK(s) → Build APK(s)** или `gradle assembleDebug`.

## 3. Первоначальная настройка на смартфоне (включая OxygenOS / MIUI / OneUI)
Откройте вкладку **«Система»** внутри приложения — мастер настройки покажет статус каждого разрешения и кнопки быстрого перехода:
1. **Микрофон и уведомления** (`RECORD_AUDIO`, `POST_NOTIFICATIONS`) — подтвердите при запуске.
2. **Захват экрана (`MediaProjection`)** — нажмите *«Разрешить»* напротив пункта «Захват экрана», подтвердите системный диалог Android (без обхода системного подтверждения).
3. **Специальные возможности (`AccessibilityService`)** — включите *«BOB AI — Визуальное и UI управление»*. На Android 13+/OxygenOS при сером переключателе откройте *О приложении → три точки в правом верхнем углу → Разрешить ограниченные настройки*.
4. **Работа в фоне без ограничений** — отключите оптимизацию батареи для BOB AI и закрепите приложение в меню недавних задач (на OnePlus/OxygenOS отключите приостановку неактивного приложения).
5. **Опционально**: «Не беспокоить», `WRITE_SETTINGS` (яркость), `NotificationListenerService` (чтение уведомлений и медиа), встроенный `BobVpnService`.

## 4. Настройка AI-провайдеров и Vision-моделей
1. Во вкладке **«Система»** откройте **Google Gemini 2.5 Flash**, **OpenAI Vision API** или **Локальную модель (Ollama)**.
2. Укажите API-ключ (шифруется в `EncryptedSharedPreferences` AES256-GCM) и включите флаг **«Поддержка изображений (Vision)»**. Текстовые модели без поддержки изображений в Visual Agent не допускаются.
3. При наличии ограничений Android (например, экраны с `FLAG_SECURE`, фоновый микрофон при выключенном экране на Android 12+, запрет скрытого переключения Wi-Fi на Android 10+ или Bluetooth на Android 13+) Боб честно сообщает о системном ограничении и использует официальную панель либо визуальное управление интерфейсом.
